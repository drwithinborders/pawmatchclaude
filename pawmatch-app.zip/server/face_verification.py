"""
Face Verification Service using InsightFace
This service handles face verification for PawMatch to prevent catfishing
"""

import os
import sys
import numpy as np
from flask import Flask, request, jsonify
from flask_cors import CORS
import cv2
import insightface
from insightface.app import FaceAnalysis
import base64
import io
from PIL import Image
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# Initialize InsightFace
face_app = None

def init_face_app():
    """Initialize the InsightFace application"""
    global face_app
    try:
        # Initialize FaceAnalysis with the best available model
        face_app = FaceAnalysis(
            name='buffalo_l',  # Using buffalo_l model for better accuracy
            providers=['CPUExecutionProvider']  # Use GPU if available: 'CUDAExecutionProvider'
        )
        face_app.prepare(ctx_id=0, det_size=(640, 640))
        logger.info("InsightFace initialized successfully")
    except Exception as e:
        logger.error(f"Error initializing InsightFace: {e}")
        # Fallback to a lighter model if buffalo_l fails
        try:
            face_app = FaceAnalysis(providers=['CPUExecutionProvider'])
            face_app.prepare(ctx_id=0, det_size=(640, 640))
            logger.info("InsightFace initialized with default model")
        except Exception as e2:
            logger.error(f"Failed to initialize InsightFace completely: {e2}")
            raise

def decode_base64_image(base64_string):
    """Decode base64 image to numpy array"""
    try:
        # Remove data URL prefix if present
        if ',' in base64_string:
            base64_string = base64_string.split(',')[1]
        
        # Decode base64 to bytes
        img_bytes = base64.b64decode(base64_string)
        
        # Convert to PIL Image
        img = Image.open(io.BytesIO(img_bytes))
        
        # Convert to RGB if necessary
        if img.mode != 'RGB':
            img = img.convert('RGB')
        
        # Convert to numpy array
        img_array = np.array(img)
        
        return img_array
    except Exception as e:
        logger.error(f"Error decoding image: {e}")
        return None

def extract_face_embedding(image):
    """Extract face embedding from an image"""
    try:
        # Detect and analyze faces
        faces = face_app.get(image)
        
        if not faces:
            logger.warning("No face detected in image")
            return None
        
        # Get the first (most prominent) face
        face = faces[0]
        
        # Return the embedding vector
        return face.embedding
    except Exception as e:
        logger.error(f"Error extracting face embedding: {e}")
        return None

def calculate_similarity(embedding1, embedding2):
    """Calculate cosine similarity between two face embeddings"""
    try:
        # Normalize embeddings
        embedding1 = embedding1 / np.linalg.norm(embedding1)
        embedding2 = embedding2 / np.linalg.norm(embedding2)
        
        # Calculate cosine similarity
        similarity = np.dot(embedding1, embedding2)
        
        # Convert to percentage
        similarity_percentage = (similarity + 1) / 2 * 100
        
        return similarity_percentage
    except Exception as e:
        logger.error(f"Error calculating similarity: {e}")
        return 0

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'service': 'PawMatch Face Verification',
        'insightface_ready': face_app is not None
    })

@app.route('/verify', methods=['POST'])
def verify_faces():
    """
    Verify if two faces belong to the same person
    Expects JSON with 'selfie' and 'profile_photo' as base64 encoded images
    """
    try:
        data = request.get_json()
        
        if not data or 'selfie' not in data or 'profile_photo' not in data:
            return jsonify({
                'error': 'Missing required images',
                'verified': False
            }), 400
        
        # Decode images
        selfie = decode_base64_image(data['selfie'])
        profile_photo = decode_base64_image(data['profile_photo'])
        
        if selfie is None or profile_photo is None:
            return jsonify({
                'error': 'Failed to decode images',
                'verified': False
            }), 400
        
        # Extract embeddings
        selfie_embedding = extract_face_embedding(selfie)
        profile_embedding = extract_face_embedding(profile_photo)
        
        if selfie_embedding is None:
            return jsonify({
                'error': 'No face detected in selfie',
                'verified': False,
                'reason': 'no_face_in_selfie'
            }), 200
        
        if profile_embedding is None:
            return jsonify({
                'error': 'No face detected in profile photo',
                'verified': False,
                'reason': 'no_face_in_profile'
            }), 200
        
        # Calculate similarity
        similarity = calculate_similarity(selfie_embedding, profile_embedding)
        
        # Threshold for verification (adjust based on your needs)
        threshold = 70.0  # 70% similarity required
        verified = similarity >= threshold
        
        return jsonify({
            'verified': verified,
            'similarity': float(similarity),
            'threshold': threshold,
            'message': 'Face verification successful' if verified else 'Faces do not match',
            'confidence': 'high' if similarity > 85 else 'medium' if similarity > 70 else 'low'
        })
        
    except Exception as e:
        logger.error(f"Error in face verification: {e}")
        return jsonify({
            'error': 'Internal server error',
            'verified': False
        }), 500

@app.route('/verify-multiple', methods=['POST'])
def verify_against_multiple():
    """
    Verify a selfie against multiple profile photos
    Returns true if the selfie matches ANY of the profile photos
    """
    try:
        data = request.get_json()
        
        if not data or 'selfie' not in data or 'profile_photos' not in data:
            return jsonify({
                'error': 'Missing required data',
                'verified': False
            }), 400
        
        # Decode selfie
        selfie = decode_base64_image(data['selfie'])
        if selfie is None:
            return jsonify({
                'error': 'Failed to decode selfie',
                'verified': False
            }), 400
        
        # Extract selfie embedding
        selfie_embedding = extract_face_embedding(selfie)
        if selfie_embedding is None:
            return jsonify({
                'error': 'No face detected in selfie',
                'verified': False,
                'reason': 'no_face_in_selfie'
            }), 200
        
        # Check against each profile photo
        similarities = []
        for idx, profile_photo_base64 in enumerate(data['profile_photos']):
            profile_photo = decode_base64_image(profile_photo_base64)
            if profile_photo is None:
                continue
            
            profile_embedding = extract_face_embedding(profile_photo)
            if profile_embedding is None:
                continue
            
            similarity = calculate_similarity(selfie_embedding, profile_embedding)
            similarities.append({
                'photo_index': idx,
                'similarity': float(similarity)
            })
        
        if not similarities:
            return jsonify({
                'error': 'No valid faces found in profile photos',
                'verified': False,
                'reason': 'no_valid_profile_faces'
            }), 200
        
        # Get the best match
        best_match = max(similarities, key=lambda x: x['similarity'])
        threshold = 70.0
        verified = best_match['similarity'] >= threshold
        
        return jsonify({
            'verified': verified,
            'best_match': best_match,
            'all_similarities': similarities,
            'threshold': threshold,
            'message': 'Verification successful' if verified else 'No matching face found'
        })
        
    except Exception as e:
        logger.error(f"Error in multiple face verification: {e}")
        return jsonify({
            'error': 'Internal server error',
            'verified': False
        }), 500

@app.route('/detect-face', methods=['POST'])
def detect_face():
    """
    Simple face detection endpoint
    Returns whether a face is detected and face quality metrics
    """
    try:
        data = request.get_json()
        
        if not data or 'image' not in data:
            return jsonify({
                'error': 'Missing image',
                'face_detected': False
            }), 400
        
        # Decode image
        image = decode_base64_image(data['image'])
        if image is None:
            return jsonify({
                'error': 'Failed to decode image',
                'face_detected': False
            }), 400
        
        # Detect faces
        faces = face_app.get(image)
        
        if not faces:
            return jsonify({
                'face_detected': False,
                'face_count': 0,
                'message': 'No face detected'
            })
        
        # Get face details
        face = faces[0]
        bbox = face.bbox.tolist()
        
        # Calculate face size relative to image
        img_height, img_width = image.shape[:2]
        face_width = bbox[2] - bbox[0]
        face_height = bbox[3] - bbox[1]
        face_area_ratio = (face_width * face_height) / (img_width * img_height)
        
        # Quality assessment
        quality = 'good'
        if face_area_ratio < 0.05:
            quality = 'too_small'
        elif face_area_ratio > 0.7:
            quality = 'too_close'
        
        return jsonify({
            'face_detected': True,
            'face_count': len(faces),
            'face_quality': quality,
            'face_area_ratio': float(face_area_ratio),
            'bbox': bbox,
            'message': 'Face detected successfully'
        })
        
    except Exception as e:
        logger.error(f"Error in face detection: {e}")
        return jsonify({
            'error': 'Internal server error',
            'face_detected': False
        }), 500

if __name__ == '__main__':
    # Initialize InsightFace on startup
    init_face_app()
    
    # Run the Flask app
    port = int(os.environ.get('FACE_VERIFICATION_PORT', 5001))
    app.run(host='0.0.0.0', port=port, debug=False)
