import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import multer from 'multer';
import mongoose from 'mongoose';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import axios from 'axios';
import FormData from 'form-data';
import sharp from 'sharp';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import fs from 'fs/promises';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;
const FACE_VERIFICATION_URL = process.env.FACE_VERIFICATION_URL || 'http://localhost:5001';

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// MongoDB connection
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/pawmatch', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Multer setup for file uploads
const storage = multer.memoryStorage();
const upload = multer({ 
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
});

// User Schema
const userSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  name: { type: String, required: true },
  isVerified: { type: Boolean, default: false },
  verificationAttempts: { type: Number, default: 0 },
  verificationData: {
    verifiedAt: Date,
    similarity: Number,
    selfieUrl: String,
  },
  profilePhotos: [String],
  pets: [{
    name: String,
    age: Number,
    breed: String,
    bio: String,
    images: [String],
    tags: [String],
  }],
  createdAt: { type: Date, default: Date.now },
});

const User = mongoose.model('User', userSchema);

// Match Schema
const matchSchema = new mongoose.Schema({
  user1: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  user2: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  pet1: { type: mongoose.Schema.Types.ObjectId },
  pet2: { type: mongoose.Schema.Types.ObjectId },
  status: { type: String, enum: ['pending', 'matched', 'unmatched'], default: 'pending' },
  createdAt: { type: Date, default: Date.now },
});

const Match = mongoose.model('Match', matchSchema);

// Like Schema
const likeSchema = new mongoose.Schema({
  fromUser: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  toUser: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  fromPet: { type: mongoose.Schema.Types.ObjectId },
  toPet: { type: mongoose.Schema.Types.ObjectId },
  isSuperLike: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now },
});

const Like = mongoose.model('Like', likeSchema);

// Auth Middleware
const authMiddleware = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (!token) {
      throw new Error();
    }
    
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key');
    const user = await User.findById(decoded.userId).select('-password');
    
    if (!user) {
      throw new Error();
    }
    
    req.user = user;
    req.token = token;
    next();
  } catch (error) {
    res.status(401).json({ error: 'Please authenticate' });
  }
};

// Helper function to convert image to base64
async function imageToBase64(buffer) {
  return `data:image/jpeg;base64,${buffer.toString('base64')}`;
}

// Routes

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'healthy', service: 'PawMatch Backend' });
});

// Auth Routes
app.post('/api/auth/register', async (req, res) => {
  try {
    const { email, password, name } = req.body;
    
    // Check if user exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ error: 'Email already registered' });
    }
    
    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);
    
    // Create user
    const user = new User({
      email,
      password: hashedPassword,
      name,
    });
    
    await user.save();
    
    // Generate token
    const token = jwt.sign(
      { userId: user._id },
      process.env.JWT_SECRET || 'your-secret-key',
      { expiresIn: '7d' }
    );
    
    res.status(201).json({
      token,
      user: {
        id: user._id,
        email: user.email,
        name: user.name,
        isVerified: user.isVerified,
      },
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ error: 'Failed to register user' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    // Find user
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    // Check password
    const isValid = await bcrypt.compare(password, user.password);
    if (!isValid) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    // Generate token
    const token = jwt.sign(
      { userId: user._id },
      process.env.JWT_SECRET || 'your-secret-key',
      { expiresIn: '7d' }
    );
    
    res.json({
      token,
      user: {
        id: user._id,
        email: user.email,
        name: user.name,
        isVerified: user.isVerified,
      },
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Failed to login' });
  }
});

// Face Verification Routes
app.post('/api/verification/verify-face', authMiddleware, upload.single('selfie'), async (req, res) => {
  try {
    const user = req.user;
    
    // Check verification attempts
    if (user.verificationAttempts >= 3) {
      return res.status(429).json({
        error: 'Maximum verification attempts reached',
        verified: false,
      });
    }
    
    // Get selfie from upload
    if (!req.file) {
      return res.status(400).json({
        error: 'No selfie provided',
        verified: false,
      });
    }
    
    // Process image with sharp (resize and optimize)
    const processedImage = await sharp(req.file.buffer)
      .resize(800, 800, { fit: 'inside' })
      .jpeg({ quality: 90 })
      .toBuffer();
    
    // Convert to base64
    const selfieBase64 = await imageToBase64(processedImage);
    
    // Get user's profile photos (you'll need to implement this based on your storage)
    // For now, using dummy data
    const profilePhotos = user.profilePhotos || [];
    
    if (profilePhotos.length === 0) {
      return res.status(400).json({
        error: 'No profile photos to verify against',
        verified: false,
      });
    }
    
    // Call Python face verification service
    try {
      const verificationResponse = await axios.post(
        `${FACE_VERIFICATION_URL}/verify-multiple`,
        {
          selfie: selfieBase64,
          profile_photos: profilePhotos,
        },
        {
          headers: { 'Content-Type': 'application/json' },
          timeout: 30000, // 30 second timeout
        }
      );
      
      const result = verificationResponse.data;
      
      // Update user verification status
      if (result.verified) {
        user.isVerified = true;
        user.verificationData = {
          verifiedAt: new Date(),
          similarity: result.best_match?.similarity,
          selfieUrl: selfieBase64, // In production, store in cloud storage
        };
        await user.save();
        
        return res.json({
          verified: true,
          similarity: result.best_match?.similarity,
          message: 'Verification successful!',
        });
      } else {
        // Increment attempts
        user.verificationAttempts += 1;
        await user.save();
        
        return res.json({
          verified: false,
          reason: result.reason || 'Faces do not match',
          attemptsRemaining: 3 - user.verificationAttempts,
          message: 'Verification failed. Please try again.',
        });
      }
    } catch (verificationError) {
      console.error('Face verification service error:', verificationError);
      
      // Check if Python service is running
      if (verificationError.code === 'ECONNREFUSED') {
        return res.status(503).json({
          error: 'Face verification service is unavailable',
          verified: false,
          message: 'Please try again later',
        });
      }
      
      throw verificationError;
    }
  } catch (error) {
    console.error('Verification error:', error);
    res.status(500).json({
      error: 'Verification failed',
      verified: false,
    });
  }
});

// Pet Discovery Routes
app.get('/api/pets/discover', authMiddleware, async (req, res) => {
  try {
    // Get all users except current user
    const users = await User.find({ 
      _id: { $ne: req.user._id } 
    }).select('pets isVerified name');
    
    // Flatten all pets from all users
    const allPets = [];
    users.forEach(user => {
      if (user.pets && user.pets.length > 0) {
        user.pets.forEach(pet => {
          allPets.push({
            id: pet._id,
            name: pet.name,
            age: pet.age,
            breed: pet.breed,
            bio: pet.bio,
            images: pet.images || ['/placeholder-pet.jpg'],
            tags: pet.tags || [],
            ownerVerified: user.isVerified,
            ownerId: user._id,
            ownerName: user.name,
            distance: Math.floor(Math.random() * 20) + 1, // Mock distance
          });
        });
      }
    });
    
    // Shuffle array
    const shuffled = allPets.sort(() => Math.random() - 0.5);
    
    // Return max 10 pets
    res.json(shuffled.slice(0, 10));
  } catch (error) {
    console.error('Discovery error:', error);
    res.status(500).json({ error: 'Failed to fetch pets' });
  }
});

// Like/Unlike Routes
app.post('/api/pets/:petId/like', authMiddleware, async (req, res) => {
  try {
    const { petId } = req.params;
    const fromUser = req.user._id;
    
    // Find pet owner
    const petOwner = await User.findOne({ 'pets._id': petId });
    if (!petOwner) {
      return res.status(404).json({ error: 'Pet not found' });
    }
    
    // Check if already liked
    const existingLike = await Like.findOne({
      fromUser,
      toPet: petId,
    });
    
    if (existingLike) {
      return res.status(400).json({ error: 'Already liked' });
    }
    
    // Create like
    const like = new Like({
      fromUser,
      toUser: petOwner._id,
      fromPet: req.user.pets?.[0]?._id, // Assuming first pet
      toPet: petId,
      isSuperLike: false,
    });
    
    await like.save();
    
    // Check for mutual like (match)
    const mutualLike = await Like.findOne({
      fromUser: petOwner._id,
      toUser: fromUser,
    });
    
    if (mutualLike) {
      // Create match
      const match = new Match({
        user1: fromUser,
        user2: petOwner._id,
        pet1: req.user.pets?.[0]?._id,
        pet2: petId,
        status: 'matched',
      });
      
      await match.save();
      
      return res.json({ 
        liked: true, 
        matched: true,
        message: "It's a match! 🎉",
      });
    }
    
    res.json({ liked: true, matched: false });
  } catch (error) {
    console.error('Like error:', error);
    res.status(500).json({ error: 'Failed to like pet' });
  }
});

app.post('/api/pets/:petId/super-like', authMiddleware, async (req, res) => {
  try {
    const { petId } = req.params;
    const fromUser = req.user._id;
    
    // Similar to like but with isSuperLike: true
    const petOwner = await User.findOne({ 'pets._id': petId });
    if (!petOwner) {
      return res.status(404).json({ error: 'Pet not found' });
    }
    
    const existingLike = await Like.findOne({
      fromUser,
      toPet: petId,
    });
    
    if (existingLike) {
      // Update to super like
      existingLike.isSuperLike = true;
      await existingLike.save();
    } else {
      // Create super like
      const like = new Like({
        fromUser,
        toUser: petOwner._id,
        fromPet: req.user.pets?.[0]?._id,
        toPet: petId,
        isSuperLike: true,
      });
      
      await like.save();
    }
    
    res.json({ superLiked: true });
  } catch (error) {
    console.error('Super like error:', error);
    res.status(500).json({ error: 'Failed to super like pet' });
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 PawMatch server running on port ${PORT}`);
  console.log(`📸 Face verification service expected at ${FACE_VERIFICATION_URL}`);
});
