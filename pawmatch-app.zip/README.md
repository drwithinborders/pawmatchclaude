# 🐾 PawMatch - Pet Dating App with Face Verification

A modern pet dating app with a Whiskr-style UI and InsightFace-powered anti-catfishing verification system.

![PawMatch Logo](./client/public/logo.png)

## ✨ Features

- **Beautiful Whiskr-Style UI**: Clean, modern card-based interface with swipeable pet profiles
- **Face Verification**: InsightFace-powered verification to prevent catfishing
- **Real-time Matching**: Like, Super Like, and instant match notifications
- **Verified Badges**: Blue checkmarks for verified profiles
- **Responsive Design**: Works perfectly on mobile and desktop

## 🛠️ Tech Stack

### Frontend
- React 18 with Vite
- TailwindCSS for styling
- Framer Motion for animations
- React Tinder Card for swipe functionality
- React Webcam for selfie capture
- Zustand for state management

### Backend
- Node.js with Express
- MongoDB for database
- JWT authentication
- Multer for file uploads
- Sharp for image processing

### Face Verification
- Python Flask microservice
- InsightFace for face recognition
- ONNX Runtime for ML inference
- OpenCV for image processing

## 📋 Prerequisites

- Node.js 18+ and npm
- Python 3.8+
- MongoDB (local or cloud)
- Git

## 🚀 Quick Start

### 1. Clone the Repository
```bash
git clone <your-repo-url>
cd pawmatch-app
```

### 2. Install Dependencies

#### Install all Node.js dependencies:
```bash
npm run install-all
```

#### Install Python dependencies for face verification:
```bash
cd server
pip install -r requirements.txt
cd ..
```

### 3. Environment Setup

Create `.env` file in the `server` directory:
```env
PORT=3001
MONGODB_URI=mongodb://localhost:27017/pawmatch
JWT_SECRET=your-super-secret-jwt-key-change-this
FACE_VERIFICATION_URL=http://localhost:5001
```

Create `.env` file in the `client` directory:
```env
VITE_API_URL=http://localhost:3001/api
```

### 4. Download InsightFace Models

The face verification service will automatically download the required models on first run. Make sure you have a stable internet connection.

### 5. Start the Application

#### Option 1: Start Everything Together (Recommended)
```bash
# From the root directory
npm run dev
```

This will start:
- React frontend on http://localhost:5173
- Node.js backend on http://localhost:3001
- Python face verification service on http://localhost:5001

#### Option 2: Start Services Individually

Terminal 1 - Start MongoDB:
```bash
mongod
```

Terminal 2 - Start Face Verification Service:
```bash
cd server
python face_verification.py
```

Terminal 3 - Start Backend Server:
```bash
cd server
npm run dev
```

Terminal 4 - Start Frontend:
```bash
cd client
npm run dev
```

## 📱 Using the App

1. **Register**: Create an account with email and password
2. **Upload Photos**: Add photos of your pet(s)
3. **Verify Profile**: Complete face verification to get the blue checkmark
4. **Start Swiping**: Browse and match with other pets
5. **Chat**: Message your matches

## 🔒 Face Verification Flow

1. User clicks "Verify Profile" button
2. App guides user through taking a selfie
3. Selfie is compared against profile photos using InsightFace
4. If similarity > 70%, user gets verified badge
5. Maximum 3 attempts allowed per user

## 🐳 Docker Deployment (Optional)

```bash
# Build and run with Docker Compose
docker-compose up --build
```

## 📂 Project Structure

```
pawmatch-app/
├── client/                 # React frontend
│   ├── src/
│   │   ├── components/    # Reusable components
│   │   ├── pages/        # Page components
│   │   ├── contexts/      # React contexts
│   │   ├── services/      # API services
│   │   └── App.jsx        # Main app component
│   └── package.json
├── server/                 # Backend services
│   ├── server.js          # Express server
│   ├── face_verification.py # Python face verification
│   ├── requirements.txt   # Python dependencies
│   └── package.json
└── README.md
```

## 🔧 Troubleshooting

### InsightFace Installation Issues
If you encounter issues installing InsightFace:
```bash
# On macOS
brew install cmake
pip install --upgrade pip wheel

# On Ubuntu/Debian
sudo apt-get install cmake
pip install --upgrade pip wheel
```

### MongoDB Connection Issues
Make sure MongoDB is running:
```bash
# Check MongoDB status
mongod --version

# Start MongoDB
mongod --dbpath /path/to/data/directory
```

### Face Verification Service Not Working
1. Check Python version (3.8+ required)
2. Ensure all Python dependencies are installed
3. Check if port 5001 is available
4. Look for error messages in the console

## 🎨 Customization

### Changing Colors
Edit the color palette in `client/tailwind.config.js`:
```javascript
colors: {
  primary: {
    500: '#ff4458', // Your primary color
  },
  secondary: {
    600: '#16a34a', // Your secondary color
  }
}
```

### Adjusting Face Verification Threshold
Edit the threshold in `server/face_verification.py`:
```python
threshold = 70.0  # Adjust between 0-100
```

## 📝 API Documentation

### Authentication Endpoints
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user

### Pet Discovery
- `GET /api/pets/discover` - Get pets to swipe
- `POST /api/pets/:petId/like` - Like a pet
- `POST /api/pets/:petId/super-like` - Super like a pet

### Face Verification
- `POST /api/verification/verify-face` - Verify user face

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License.

## 🙏 Acknowledgments

- InsightFace team for the amazing face recognition library
- Whiskr for UI inspiration
- React Tinder Card for swipe functionality

## 📧 Support

For support, email support@pawmatch.com or open an issue in the repository.

---

Made with ❤️ for pet lovers everywhere 🐾
