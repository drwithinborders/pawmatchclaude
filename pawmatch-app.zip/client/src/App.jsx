import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider } from './contexts/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import Navigation from './components/Navigation';
import Discovery from './pages/Discovery';
import Matches from './pages/Matches';
import Profile from './pages/Profile';
import Login from './pages/Login';
import Register from './pages/Register';
import VerificationFlow from './pages/VerificationFlow';
import Chat from './pages/Chat';

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen bg-gray-50">
          <Toaster 
            position="top-center"
            toastOptions={{
              duration: 3000,
              style: {
                background: '#363636',
                color: '#fff',
                borderRadius: '12px',
              },
              success: {
                iconTheme: {
                  primary: '#22c55e',
                  secondary: '#fff',
                },
              },
              error: {
                iconTheme: {
                  primary: '#ff4458',
                  secondary: '#fff',
                },
              },
            }}
          />
          
          <Routes>
            {/* Public Routes */}
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            
            {/* Protected Routes with Navigation */}
            <Route path="/" element={
              <ProtectedRoute>
                <div className="flex flex-col h-screen">
                  <div className="flex-1 overflow-hidden">
                    <Discovery />
                  </div>
                  <Navigation />
                </div>
              </ProtectedRoute>
            } />
            
            <Route path="/matches" element={
              <ProtectedRoute>
                <div className="flex flex-col h-screen">
                  <div className="flex-1 overflow-hidden">
                    <Matches />
                  </div>
                  <Navigation />
                </div>
              </ProtectedRoute>
            } />
            
            <Route path="/profile" element={
              <ProtectedRoute>
                <div className="flex flex-col h-screen">
                  <div className="flex-1 overflow-hidden">
                    <Profile />
                  </div>
                  <Navigation />
                </div>
              </ProtectedRoute>
            } />
            
            <Route path="/chat/:matchId" element={
              <ProtectedRoute>
                <Chat />
              </ProtectedRoute>
            } />
            
            <Route path="/verify" element={
              <ProtectedRoute>
                <VerificationFlow />
              </ProtectedRoute>
            } />
            
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;
