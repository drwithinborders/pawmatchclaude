import React, { useState, useRef, useCallback } from 'react';
import Webcam from 'react-webcam';
import { motion, AnimatePresence } from 'framer-motion';
import { Camera, Shield, Check, X, AlertCircle, ChevronRight, RefreshCw } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import toast from 'react-hot-toast';

const VerificationFlow = () => {
  const navigate = useNavigate();
  const webcamRef = useRef(null);
  const [step, setStep] = useState('intro'); // intro, capture, processing, success, failed
  const [capturedImage, setCapturedImage] = useState(null);
  const [verificationResult, setVerificationResult] = useState(null);
  const [attempts, setAttempts] = useState(0);
  const maxAttempts = 3;

  const capture = useCallback(() => {
    const imageSrc = webcamRef.current.getScreenshot();
    setCapturedImage(imageSrc);
    setStep('confirm');
  }, [webcamRef]);

  const retakePhoto = () => {
    setCapturedImage(null);
    setStep('capture');
  };

  const submitVerification = async () => {
    setStep('processing');
    
    try {
      // Convert base64 to blob
      const response = await fetch(capturedImage);
      const blob = await response.blob();
      
      // Create FormData
      const formData = new FormData();
      formData.append('selfie', blob, 'selfie.jpg');
      
      // Send to backend for verification
      const result = await api.post('/verification/verify-face', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      
      if (result.data.verified) {
        setVerificationResult(result.data);
        setStep('success');
        toast.success('Verification successful!');
      } else {
        setAttempts(prev => prev + 1);
        setVerificationResult(result.data);
        setStep('failed');
        
        if (attempts + 1 >= maxAttempts) {
          toast.error('Maximum verification attempts reached. Please contact support.');
        }
      }
    } catch (error) {
      console.error('Verification error:', error);
      toast.error('Verification failed. Please try again.');
      setStep('failed');
      setAttempts(prev => prev + 1);
    }
  };

  const renderStep = () => {
    switch (step) {
      case 'intro':
        return (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center justify-center min-h-screen p-6 bg-gradient-to-br from-blue-50 to-white"
          >
            <div className="max-w-md w-full">
              <div className="text-center mb-8">
                <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Shield className="w-12 h-12 text-blue-600" />
                </div>
                <h1 className="text-3xl font-bold text-gray-900 mb-3">
                  Verify Your Profile
                </h1>
                <p className="text-gray-600 mb-6">
                  Help us keep PawMatch safe by verifying you're a real person. This helps prevent catfishing and creates a trusted community.
                </p>
              </div>

              <div className="bg-white rounded-2xl shadow-sm p-6 mb-6">
                <h3 className="font-semibold text-gray-900 mb-4">How it works:</h3>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-primary-600 font-semibold text-sm">1</span>
                    </div>
                    <div>
                      <p className="text-gray-800 font-medium">Take a selfie</p>
                      <p className="text-gray-500 text-sm">We'll guide you through taking a clear photo</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-primary-600 font-semibold text-sm">2</span>
                    </div>
                    <div>
                      <p className="text-gray-800 font-medium">We verify it's you</p>
                      <p className="text-gray-500 text-sm">Our AI compares your selfie with your profile photos</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-primary-600 font-semibold text-sm">3</span>
                    </div>
                    <div>
                      <p className="text-gray-800 font-medium">Get verified badge</p>
                      <p className="text-gray-500 text-sm">Show others you're genuine with a blue checkmark</p>
                    </div>
                  </div>
                </div>
              </div>

              <button
                onClick={() => setStep('capture')}
                className="w-full bg-gradient-to-r from-primary-500 to-primary-600 text-white py-4 rounded-full font-semibold text-lg hover:from-primary-600 hover:to-primary-700 transition-all flex items-center justify-center space-x-2"
              >
                <span>Start Verification</span>
                <ChevronRight className="w-5 h-5" />
              </button>
              
              <button
                onClick={() => navigate('/')}
                className="w-full mt-3 text-gray-500 py-3 font-medium"
              >
                I'll do this later
              </button>
            </div>
          </motion.div>
        );

      case 'capture':
        return (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col min-h-screen bg-black"
          >
            <div className="flex-1 relative">
              <Webcam
                ref={webcamRef}
                audio={false}
                screenshotFormat="image/jpeg"
                className="w-full h-full object-cover"
                videoConstraints={{
                  facingMode: "user",
                  width: 720,
                  height: 1280
                }}
              />
              
              {/* Face guide overlay */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-64 h-80 border-4 border-white/50 rounded-3xl"></div>
              </div>
              
              {/* Instructions */}
              <div className="absolute top-0 left-0 right-0 p-6 bg-gradient-to-b from-black/60 to-transparent">
                <h2 className="text-white text-xl font-semibold text-center mb-2">
                  Position your face in the frame
                </h2>
                <p className="text-white/80 text-center text-sm">
                  Make sure your face is clearly visible and well-lit
                </p>
              </div>
              
              {/* Capture button */}
              <div className="absolute bottom-0 left-0 right-0 p-8 bg-gradient-to-t from-black/60 to-transparent">
                <button
                  onClick={capture}
                  className="w-20 h-20 bg-white rounded-full mx-auto flex items-center justify-center hover:scale-110 transition-transform"
                >
                  <div className="w-16 h-16 bg-primary-500 rounded-full flex items-center justify-center">
                    <Camera className="w-8 h-8 text-white" />
                  </div>
                </button>
              </div>
              
              {/* Cancel button */}
              <button
                onClick={() => setStep('intro')}
                className="absolute top-6 right-6 text-white p-2"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
          </motion.div>
        );

      case 'confirm':
        return (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col min-h-screen bg-gray-50"
          >
            <div className="flex-1 flex flex-col">
              <div className="p-6">
                <h2 className="text-2xl font-bold text-gray-900 text-center mb-2">
                  Review Your Photo
                </h2>
                <p className="text-gray-600 text-center">
                  Make sure your face is clearly visible
                </p>
              </div>
              
              <div className="flex-1 px-6">
                <div className="relative rounded-2xl overflow-hidden shadow-lg">
                  <img 
                    src={capturedImage} 
                    alt="Captured selfie" 
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
              
              <div className="p-6 space-y-3">
                <button
                  onClick={submitVerification}
                  className="w-full bg-gradient-to-r from-primary-500 to-primary-600 text-white py-4 rounded-full font-semibold text-lg hover:from-primary-600 hover:to-primary-700 transition-all"
                >
                  Verify This Photo
                </button>
                
                <button
                  onClick={retakePhoto}
                  className="w-full bg-gray-200 text-gray-800 py-4 rounded-full font-semibold text-lg hover:bg-gray-300 transition-colors flex items-center justify-center space-x-2"
                >
                  <RefreshCw className="w-5 h-5" />
                  <span>Retake Photo</span>
                </button>
              </div>
            </div>
          </motion.div>
        );

      case 'processing':
        return (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex items-center justify-center min-h-screen bg-gradient-to-br from-primary-50 to-white"
          >
            <div className="text-center">
              <div className="relative w-32 h-32 mx-auto mb-6">
                <div className="absolute inset-0 border-4 border-primary-200 rounded-full"></div>
                <div className="absolute inset-0 border-4 border-primary-500 rounded-full border-t-transparent animate-spin"></div>
                <Shield className="w-12 h-12 text-primary-500 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Verifying...</h3>
              <p className="text-gray-600">This will just take a moment</p>
            </div>
          </motion.div>
        );

      case 'success':
        return (
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="flex items-center justify-center min-h-screen bg-gradient-to-br from-green-50 to-white p-6"
          >
            <div className="max-w-md w-full text-center">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", delay: 0.2 }}
                className="w-32 h-32 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6"
              >
                <Check className="w-16 h-16 text-green-600" />
              </motion.div>
              
              <h1 className="text-3xl font-bold text-gray-900 mb-3">
                You're Verified! 🎉
              </h1>
              <p className="text-gray-600 mb-8">
                Your profile now has the verified badge. Other users will see you're a real person.
              </p>
              
              <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 mb-8">
                <div className="flex items-center justify-center space-x-2 text-blue-700">
                  <Shield className="w-5 h-5" />
                  <span className="font-semibold">Profile Verified</span>
                </div>
              </div>
              
              <button
                onClick={() => navigate('/')}
                className="w-full bg-gradient-to-r from-primary-500 to-primary-600 text-white py-4 rounded-full font-semibold text-lg hover:from-primary-600 hover:to-primary-700 transition-all"
              >
                Continue to PawMatch
              </button>
            </div>
          </motion.div>
        );

      case 'failed':
        return (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex items-center justify-center min-h-screen bg-gradient-to-br from-red-50 to-white p-6"
          >
            <div className="max-w-md w-full text-center">
              <div className="w-32 h-32 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <AlertCircle className="w-16 h-16 text-red-600" />
              </div>
              
              <h1 className="text-3xl font-bold text-gray-900 mb-3">
                Verification Failed
              </h1>
              <p className="text-gray-600 mb-6">
                We couldn't verify your photo. This might happen if the photo is unclear or doesn't match your profile photos.
              </p>
              
              {attempts < maxAttempts && (
                <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-4 mb-8">
                  <p className="text-yellow-800 text-sm">
                    You have {maxAttempts - attempts} attempt{maxAttempts - attempts !== 1 ? 's' : ''} remaining
                  </p>
                </div>
              )}
              
              {attempts < maxAttempts ? (
                <>
                  <button
                    onClick={() => {
                      setCapturedImage(null);
                      setStep('capture');
                    }}
                    className="w-full bg-gradient-to-r from-primary-500 to-primary-600 text-white py-4 rounded-full font-semibold text-lg hover:from-primary-600 hover:to-primary-700 transition-all mb-3"
                  >
                    Try Again
                  </button>
                  
                  <button
                    onClick={() => navigate('/')}
                    className="w-full text-gray-500 py-3 font-medium"
                  >
                    I'll try later
                  </button>
                </>
              ) : (
                <button
                  onClick={() => navigate('/')}
                  className="w-full bg-gray-200 text-gray-800 py-4 rounded-full font-semibold text-lg"
                >
                  Contact Support
                </button>
              )}
            </div>
          </motion.div>
        );

      default:
        return null;
    }
  };

  return (
    <AnimatePresence mode="wait">
      {renderStep()}
    </AnimatePresence>
  );
};

export default VerificationFlow;
