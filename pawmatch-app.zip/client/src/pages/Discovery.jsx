import React, { useState, useEffect, useMemo, useRef } from 'react';
import TinderCard from 'react-tinder-card';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, X, Star, RotateCcw, Sparkles, MapPin, Info, Shield } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import api from '../services/api';
import toast from 'react-hot-toast';

const Discovery = () => {
  const [pets, setPets] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [loading, setLoading] = useState(true);
  const [lastDirection, setLastDirection] = useState();
  const { user } = useAuth();

  const currentIndexRef = useRef(currentIndex);
  const childRefs = useMemo(
    () =>
      Array(pets.length)
        .fill(0)
        .map((i) => React.createRef()),
    [pets.length]
  );

  useEffect(() => {
    fetchPets();
  }, []);

  const fetchPets = async () => {
    try {
      setLoading(true);
      const response = await api.get('/pets/discover');
      setPets(response.data);
      setCurrentIndex(response.data.length - 1);
    } catch (error) {
      toast.error('Failed to load pets');
    } finally {
      setLoading(false);
    }
  };

  const updateCurrentIndex = (val) => {
    setCurrentIndex(val);
    currentIndexRef.current = val;
  };

  const canSwipe = currentIndex >= 0;

  const swiped = async (direction, petId, index) => {
    setLastDirection(direction);
    updateCurrentIndex(index - 1);
    
    if (direction === 'right') {
      try {
        await api.post(`/pets/${petId}/like`);
        toast.success('Liked! 💕', { duration: 1500 });
      } catch (error) {
        console.error('Error liking pet:', error);
      }
    } else if (direction === 'up') {
      try {
        await api.post(`/pets/${petId}/super-like`);
        toast.success('Super Liked! ⭐', { duration: 1500 });
      } catch (error) {
        console.error('Error super liking pet:', error);
      }
    }
  };

  const outOfFrame = (name, idx) => {
    console.log(`${name} (${idx}) left the screen!`);
    currentIndexRef.current >= idx && childRefs[idx].current.restoreCard();
  };

  const swipe = async (dir) => {
    if (canSwipe && currentIndex < pets.length) {
      await childRefs[currentIndex].current.swipe(dir);
    }
  };

  const goBack = () => {
    if (!canSwipe) return;
    const newIndex = currentIndex + 1;
    updateCurrentIndex(newIndex);
    childRefs[newIndex].current.restoreCard();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full bg-gradient-to-br from-primary-50 to-white">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Finding perfect matches...</p>
        </div>
      </div>
    );
  }

  if (pets.length === 0) {
    return (
      <div className="flex items-center justify-center h-full bg-gradient-to-br from-primary-50 to-white">
        <div className="text-center p-8">
          <div className="w-24 h-24 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Heart className="w-12 h-12 text-primary-500" />
          </div>
          <h3 className="text-2xl font-bold text-gray-800 mb-2">No More Pets</h3>
          <p className="text-gray-600 mb-6">Check back later for more matches!</p>
          <button 
            onClick={fetchPets}
            className="px-6 py-3 bg-primary-500 text-white rounded-full font-medium hover:bg-primary-600 transition-colors"
          >
            Refresh
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full bg-gradient-to-br from-primary-50 via-white to-secondary-50">
      {/* Header */}
      <div className="absolute top-0 left-0 right-0 z-10 px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <img src="/logo.png" alt="PawMatch" className="w-8 h-8" />
            <h1 className="text-2xl font-bold bg-gradient-to-r from-primary-500 to-primary-600 bg-clip-text text-transparent">
              PawMatch
            </h1>
          </div>
          <button className="p-2 bg-white rounded-full shadow-sm">
            <Sparkles className="w-5 h-5 text-yellow-500" />
          </button>
        </div>
      </div>

      {/* Cards Container */}
      <div className="flex items-center justify-center h-full pt-20 pb-24">
        <div className="relative w-full max-w-sm mx-4">
          {pets.map((pet, index) => (
            <TinderCard
              ref={childRefs[index]}
              key={pet.id}
              onSwipe={(dir) => swiped(dir, pet.id, index)}
              onCardLeftScreen={() => outOfFrame(pet.name, index)}
              preventSwipe={['down']}
              className="absolute w-full"
            >
              <motion.div
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.3 }}
                className="relative bg-white rounded-3xl shadow-xl overflow-hidden"
                style={{ height: '600px' }}
              >
                {/* Image Container */}
                <div className="relative h-3/4">
                  <img
                    src={pet.images?.[0] || '/placeholder-pet.jpg'}
                    alt={pet.name}
                    className="w-full h-full object-cover"
                  />
                  
                  {/* Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
                  
                  {/* Verification Badge */}
                  {pet.ownerVerified && (
                    <div className="absolute top-4 right-4 bg-blue-500 text-white px-3 py-1 rounded-full text-sm font-medium flex items-center space-x-1">
                      <Shield className="w-4 h-4" />
                      <span>Verified</span>
                    </div>
                  )}
                  
                  {/* Pet Info Overlay */}
                  <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                    <h2 className="text-3xl font-bold mb-1">{pet.name}, {pet.age}</h2>
                    <p className="text-lg opacity-90 mb-2">{pet.breed}</p>
                    <div className="flex items-center space-x-1 text-sm">
                      <MapPin className="w-4 h-4" />
                      <span>{pet.distance || '< 1'} km away</span>
                    </div>
                  </div>
                </div>

                {/* Info Section */}
                <div className="p-6">
                  <p className="text-gray-700 line-clamp-2">{pet.bio}</p>
                  <div className="flex flex-wrap gap-2 mt-3">
                    {pet.tags?.map((tag, idx) => (
                      <span 
                        key={idx}
                        className="px-3 py-1 bg-primary-100 text-primary-600 rounded-full text-sm font-medium"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            </TinderCard>
          ))}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="absolute bottom-0 left-0 right-0 pb-6">
        <div className="flex items-center justify-center space-x-4">
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => swipe('left')}
            className="w-14 h-14 bg-white rounded-full shadow-lg flex items-center justify-center text-gray-400 hover:text-red-500 transition-colors"
            disabled={!canSwipe}
          >
            <X className="w-7 h-7" />
          </motion.button>
          
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => swipe('up')}
            className="w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center text-gray-400 hover:text-blue-500 transition-colors"
            disabled={!canSwipe}
          >
            <Star className="w-6 h-6" />
          </motion.button>
          
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => swipe('right')}
            className="w-16 h-16 bg-gradient-to-br from-primary-400 to-primary-600 rounded-full shadow-lg flex items-center justify-center text-white hover:from-primary-500 hover:to-primary-700 transition-all"
            disabled={!canSwipe}
          >
            <Heart className="w-8 h-8" />
          </motion.button>
          
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={goBack}
            className="w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center text-gray-400 hover:text-yellow-500 transition-colors"
          >
            <RotateCcw className="w-6 h-6" />
          </motion.button>
        </div>
      </div>
    </div>
  );
};

export default Discovery;
