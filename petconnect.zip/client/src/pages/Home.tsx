import { useState, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { APP_TITLE, getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { 
  Heart, 
  MapPin, 
  Star, 
  Users, 
  Calendar, 
  Shield, 
  Award,
  DollarSign,
  Clock,
  Sparkles,
  PawPrint
} from "lucide-react";
import { Link, useLocation } from "wouter";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState("walkers");

  // Redirect authenticated users to discover
  useEffect(() => {
    if (user) {
      const hasSeenOnboarding = localStorage.getItem("userType");
      if (!hasSeenOnboarding) {
        setLocation("/onboarding");
      } else {
        setLocation("/discover");
      }
    }
  }, [user, setLocation]);

  const { data: walkers = [], isLoading: walkersLoading } = trpc.walkers.list.useQuery();
  const { data: pets = [], isLoading: petsLoading } = trpc.pets.list.useQuery();
  const { data: meetups = [], isLoading: meetupsLoading } = trpc.meetups.upcoming.useQuery();

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10 py-20 md:py-32">
        <div className="container">
          <div className="grid gap-12 lg:grid-cols-2 lg:gap-16 items-center">
            <div className="space-y-6">
              <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
                <Sparkles className="h-4 w-4" />
                Connecting Pet Lovers
              </div>
              <div className="mb-6">
                <img src="/images/pawmatch-logo.png" alt="PawMatch" className="h-24 w-auto" />
              </div>
              <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl lg:text-7xl">
                Find Trusted Pet Care & Make New Friends
              </h1>
              <p className="text-lg text-muted-foreground md:text-xl max-w-2xl">
                Connect with verified pet sitters and walkers, or find playmates for your furry friend. 
                Join a community built on trust, reviews, and shared love for pets.
              </p>
              <div className="flex flex-wrap gap-4">
                {isAuthenticated ? (
                  <>
                    <Button size="lg" asChild>
                      <Link href="/dashboard">Go to Dashboard</Link>
                    </Button>
                    <Button size="lg" variant="outline" onClick={() => setActiveTab("walkers")}>
                      Explore Now
                    </Button>
                  </>
                ) : (
                  <>
                    <Button size="lg" asChild>
                      <a href={getLoginUrl()}>Get Started</a>
                    </Button>
                    <Button size="lg" variant="outline" onClick={() => setActiveTab("walkers")}>
                      Browse Profiles
                    </Button>
                  </>
                )}
              </div>
            </div>
            <div className="relative">
              <img 
                src="/images/hero-dog.jpg" 
                alt="Happy dog" 
                className="rounded-3xl shadow-2xl w-full h-auto object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 md:py-24 bg-muted/30">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Why Choose PawMatch?</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              A dual-purpose platform designed for both professional pet care and social connections
            </p>
          </div>
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <Shield className="h-10 w-10 text-primary mb-2" />
                <CardTitle>Verified Professionals</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  All walkers and sitters are verified through reviews, ratings, and optional certifications for your peace of mind.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <Users className="h-10 w-10 text-secondary mb-2" />
                <CardTitle>Community Driven</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Connect with other pet owners for playdates, group walks, and shared activities. Build lasting friendships.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <Calendar className="h-10 w-10 text-accent mb-2" />
                <CardTitle>Flexible Scheduling</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Book one-time walks, recurring services, or join spontaneous meetups. No rigid commitments required.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Discovery Section */}
      <section className="py-16 md:py-24">
        <div className="container">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <div className="flex justify-center mb-8">
              <TabsList className="grid w-full max-w-md grid-cols-2">
                <TabsTrigger value="walkers">
                  <Award className="h-4 w-4 mr-2" />
                  Find Walkers
                </TabsTrigger>
                <TabsTrigger value="meetups">
                  <PawPrint className="h-4 w-4 mr-2" />
                  Dog Meetups
                </TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="walkers" className="space-y-6">
              <div className="text-center mb-8">
                <h2 className="text-3xl font-bold mb-2">Verified Pet Walkers & Sitters</h2>
                <p className="text-muted-foreground">Professional care with transparent pricing and reviews</p>
              </div>
              {walkersLoading ? (
                <div className="text-center py-12">Loading walkers...</div>
              ) : walkers.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-muted-foreground mb-4">No walkers available yet. Be the first to join!</p>
                  {isAuthenticated && (
                    <Button asChild>
                      <Link href="/dashboard">Create Walker Profile</Link>
                    </Button>
                  )}
                </div>
              ) : (
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {walkers.map((walker) => (
                    <Card key={walker.id} className="hover:shadow-lg transition-shadow">
                      <CardHeader>
                        {walker.imageUrl && (
                          <img 
                            src={walker.imageUrl} 
                            alt={walker.businessName}
                            className="w-full h-48 object-cover rounded-lg mb-4"
                          />
                        )}
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <CardTitle className="text-xl">{walker.businessName}</CardTitle>
                            <div className="flex items-center gap-2 mt-2">
                              <MapPin className="h-4 w-4 text-muted-foreground" />
                              <span className="text-sm text-muted-foreground">{walker.location || "Location not set"}</span>
                            </div>
                          </div>
                          {walker.verified && (
                            <Badge variant="secondary" className="bg-secondary/10 text-secondary">
                              <Shield className="h-3 w-3 mr-1" />
                              Verified
                            </Badge>
                          )}
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <p className="text-sm text-muted-foreground line-clamp-2">
                          {walker.about || "No description available"}
                        </p>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1">
                            <Star className="h-4 w-4 fill-primary text-primary" />
                            <span className="font-semibold">{((walker.rating || 0) / 10).toFixed(1)}</span>
                            <span className="text-sm text-muted-foreground">({walker.reviewCount} reviews)</span>
                          </div>
                          {walker.pricePerWalk && (
                            <div className="flex items-center gap-1 text-primary font-semibold">
                              <DollarSign className="h-4 w-4" />
                              {(walker.pricePerWalk / 100).toFixed(0)}
                            </div>
                          )}
                        </div>
                        {walker.services && (
                          <div className="flex flex-wrap gap-2">
                            {JSON.parse(walker.services).slice(0, 3).map((service: string, idx: number) => (
                              <Badge key={idx} variant="outline" className="text-xs">
                                {service}
                              </Badge>
                            ))}
                          </div>
                        )}
                        <Button className="w-full" variant="outline">
                          View Profile
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="meetups" className="space-y-6">
              <div className="text-center mb-8">
                <h2 className="text-3xl font-bold mb-2">Upcoming Dog Meetups</h2>
                <p className="text-muted-foreground">Find playmates and walking partners for your furry friend</p>
              </div>
              {meetupsLoading ? (
                <div className="text-center py-12">Loading meetups...</div>
              ) : meetups.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-muted-foreground mb-4">No upcoming meetups. Create the first one!</p>
                  {isAuthenticated && (
                    <Button asChild>
                      <Link href="/dashboard">Create Meetup</Link>
                    </Button>
                  )}
                </div>
              ) : (
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {meetups.map((meetup) => (
                    <Card key={meetup.id} className="hover:shadow-lg transition-shadow">
                      <CardHeader>
                        <div className="flex items-start justify-between mb-2">
                          <Badge variant="outline" className="capitalize">
                            {meetup.activityType}
                          </Badge>
                          <Badge variant="secondary" className="capitalize">
                            {meetup.energyLevel} energy
                          </Badge>
                        </div>
                        <CardTitle className="text-xl">{meetup.title}</CardTitle>
                        <CardDescription className="line-clamp-2">
                          {meetup.description || "Join us for a fun time!"}
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div className="flex items-center gap-2 text-sm">
                          <MapPin className="h-4 w-4 text-muted-foreground" />
                          <span>{meetup.location}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <Clock className="h-4 w-4 text-muted-foreground" />
                          <span>{new Date(meetup.meetupTime).toLocaleString()}</span>
                        </div>
                        {meetup.maxParticipants && (
                          <div className="flex items-center gap-2 text-sm">
                            <Users className="h-4 w-4 text-muted-foreground" />
                            <span>Max {meetup.maxParticipants} participants</span>
                          </div>
                        )}
                        <Button className="w-full" variant="outline">
                          View Details
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-gradient-to-r from-primary to-secondary text-white">
        <div className="container text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Get Started?</h2>
          <p className="text-lg mb-8 opacity-90 max-w-2xl mx-auto">
            Join our community of pet lovers today. Whether you need a trusted walker or want to meet new friends, we've got you covered.
          </p>
          {isAuthenticated ? (
            <Button size="lg" variant="secondary" asChild>
              <Link href="/dashboard">Go to Dashboard</Link>
            </Button>
          ) : (
            <Button size="lg" variant="secondary" asChild>
              <a href={getLoginUrl()}>Sign Up Now</a>
            </Button>
          )}
        </div>
      </section>
    </div>
  );
}
