import { useState, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Heart,
  X,
  MapPin,
  Star,
  Filter,
  User,
  Home,
  MessageCircle,
  Briefcase,
  Calendar,
} from "lucide-react";
import { APP_LOGO, getLoginUrl } from "@/const";
import { useLocation } from "wouter";

export default function Discover() {
  const { user, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [userType, setUserType] = useState<string>("pet-owner");
  const [showFilters, setShowFilters] = useState(false);

  // Load user type preference
  useEffect(() => {
    const savedType = localStorage.getItem("userType");
    if (savedType) {
      setUserType(savedType);
    }
  }, []);

  // Fetch data based on user type
  const { data: pets, isLoading: petsLoading } = trpc.pets.list.useQuery(
    undefined,
    { enabled: userType === "pet-owner" }
  );

  const { data: walkers, isLoading: walkersLoading } =
    trpc.walkers.list.useQuery(undefined, {
      enabled: userType === "need-walker" || userType === "walker",
    });

  const isLoading = petsLoading || walkersLoading || authLoading;

  // Determine which data to show
  const cards =
    userType === "pet-owner"
      ? pets || []
      : userType === "need-walker"
        ? walkers || []
        : [];

  const currentCard = cards[currentIndex];

  const handleSwipe = (direction: "left" | "right") => {
    if (direction === "right") {
      // Handle like/match logic here
      console.log("Liked:", currentCard);
    }

    // Move to next card
    if (currentIndex < cards.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      setCurrentIndex(0); // Loop back to start
    }
  };

  const handleUserTypeChange = (type: string) => {
    setUserType(type);
    localStorage.setItem("userType", type);
    setCurrentIndex(0);
  };

  if (!user && !authLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-50 via-white to-green-50 flex flex-col items-center justify-center p-4">
        <div className="text-center max-w-md">
          <img src={APP_LOGO} alt="PawMatch" className="h-24 w-auto mx-auto mb-6" />
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Welcome to PawMatch
          </h1>
          <p className="text-gray-600 mb-8">
            Sign in to discover pet friends and trusted care providers
          </p>
          <Button
            onClick={() => (window.location.href = getLoginUrl())}
            size="lg"
            className="w-full h-12"
          >
            Sign In to Continue
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <img src={APP_LOGO} alt="PawMatch" className="h-10 w-auto" />
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowFilters(!showFilters)}
            >
              <Filter className="h-5 w-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setLocation("/dashboard")}
            >
              <User className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* User Type Tabs */}
        <div className="container mx-auto px-4 pb-3 flex gap-2 overflow-x-auto">
          <Button
            variant={userType === "pet-owner" ? "default" : "outline"}
            onClick={() => handleUserTypeChange("pet-owner")}
            className="flex-shrink-0"
          >
            <Heart className="h-4 w-4 mr-2" />
            Find Playmates
          </Button>
          <Button
            variant={userType === "need-walker" ? "default" : "outline"}
            onClick={() => handleUserTypeChange("need-walker")}
            className="flex-shrink-0"
          >
            <Briefcase className="h-4 w-4 mr-2" />
            Find Walker/Sitter
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-6 max-w-2xl">
        {isLoading ? (
          <div className="flex items-center justify-center h-[70vh]">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-gray-600">Loading profiles...</p>
            </div>
          </div>
        ) : cards.length === 0 ? (
          <div className="flex items-center justify-center h-[70vh]">
            <div className="text-center">
              <p className="text-xl text-gray-600 mb-4">
                No profiles available yet
              </p>
              <Button onClick={() => setLocation("/dashboard")}>
                Create Your Profile
              </Button>
            </div>
          </div>
        ) : (
          <div className="relative">
            {/* Card Stack */}
            <div className="relative h-[70vh]">
              {currentCard && (
                <Card className="absolute inset-0 overflow-hidden shadow-2xl">
                  {/* Image */}
                  <div className="relative h-[60%] bg-gray-200">
                    {"imageUrl" in currentCard && currentCard.imageUrl ? (
                      <img
                        src={currentCard.imageUrl}
                        alt={"name" in currentCard ? currentCard.name : "businessName" in currentCard ? currentCard.businessName : "Profile"}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-pink-200 to-green-200">
                        <User className="h-24 w-24 text-white opacity-50" />
                      </div>
                    )}

                    {/* Distance Badge */}
                    <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm rounded-full px-3 py-1 flex items-center gap-1 shadow-lg">
                      <MapPin className="h-4 w-4 text-primary" />
                      <span className="text-sm font-medium">
                        {"location" in currentCard
                          ? currentCard.location
                          : "Malta"}
                      </span>
                    </div>
                  </div>

                  {/* Info */}
                  <div className="p-6 h-[40%] overflow-y-auto">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h2 className="text-2xl font-bold text-gray-900">
                          {"name" in currentCard ? currentCard.name : "businessName" in currentCard ? currentCard.businessName : "Unknown"}
                          {"age" in currentCard && currentCard.age && (
                            <span className="text-gray-500 font-normal">
                              , {currentCard.age}
                            </span>
                          )}
                        </h2>
                        {"breed" in currentCard && currentCard.breed && (
                          <p className="text-gray-600">{currentCard.breed}</p>
                        )}
                        {"businessName" in currentCard &&
                          currentCard.businessName && (
                            <p className="text-gray-600 font-medium">
                              {currentCard.businessName}
                            </p>
                          )}
                      </div>

                      {/* Price or Rating */}
                      {"pricePerWalk" in currentCard &&
                        currentCard.pricePerWalk && (
                          <div className="text-right">
                            <div className="text-2xl font-bold text-primary">
                              €{(currentCard.pricePerWalk / 100).toFixed(0)}
                            </div>
                            <div className="text-xs text-gray-500">per walk</div>
                          </div>
                        )}
                    </div>

                    {/* Energy Level */}
                    {"energyLevel" in currentCard && currentCard.energyLevel && (
                      <div className="mb-3">
                        <span className="inline-block bg-primary/10 text-primary px-3 py-1 rounded-full text-sm font-medium">
                          {currentCard.energyLevel} energy
                        </span>
                      </div>
                    )}

                    {/* About */}
                    {"about" in currentCard && currentCard.about && (
                      <p className="text-gray-700 mb-4">{currentCard.about}</p>
                    )}

                    {/* Services */}
                    {"services" in currentCard && currentCard.services && (
                      <div className="flex flex-wrap gap-2">
                        {JSON.parse(currentCard.services as string).map(
                          (service: string, idx: number) => (
                            <span
                              key={idx}
                              className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm"
                            >
                              {service}
                            </span>
                          )
                        )}
                      </div>
                    )}
                  </div>
                </Card>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-center gap-6 mt-6">
              <Button
                size="icon"
                variant="outline"
                className="h-16 w-16 rounded-full border-2 border-red-500 text-red-500 hover:bg-red-50 hover:text-red-600 shadow-lg"
                onClick={() => handleSwipe("left")}
              >
                <X className="h-8 w-8" />
              </Button>

              <Button
                size="icon"
                className="h-20 w-20 rounded-full shadow-xl bg-gradient-to-br from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600"
                onClick={() => handleSwipe("right")}
              >
                <Heart className="h-10 w-10" />
              </Button>

              <Button
                size="icon"
                variant="outline"
                className="h-16 w-16 rounded-full border-2 border-primary shadow-lg"
                onClick={() => setLocation("/dashboard")}
              >
                <MessageCircle className="h-7 w-7" />
              </Button>
            </div>

            {/* Progress */}
            <div className="text-center mt-4 text-sm text-gray-500">
              {currentIndex + 1} / {cards.length}
            </div>
          </div>
        )}
      </div>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 safe-area-inset-bottom">
        <div className="container mx-auto px-4 py-3 flex justify-around max-w-2xl">
          <Button variant="ghost" size="icon" onClick={() => setLocation("/")}>
            <Home className="h-6 w-6" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setLocation("/discover")}
            className="text-primary"
          >
            <Heart className="h-6 w-6" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setLocation("/meetups")}
          >
            <Calendar className="h-6 w-6" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setLocation("/dashboard")}
          >
            <User className="h-6 w-6" />
          </Button>
        </div>
      </nav>
    </div>
  );
}
