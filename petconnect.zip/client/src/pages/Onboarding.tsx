import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Heart, Users, Briefcase } from "lucide-react";
import { APP_LOGO } from "@/const";

export default function Onboarding() {
  const [, setLocation] = useLocation();
  const [selectedType, setSelectedType] = useState<string | null>(null);

  const handleContinue = () => {
    if (selectedType) {
      // Store user preference in localStorage
      localStorage.setItem("userType", selectedType);
      setLocation("/discover");
    }
  };

  const userTypes = [
    {
      id: "pet-owner",
      title: "Pet Owner",
      description: "Find playmates for your dog and organize meetups",
      icon: Heart,
      color: "from-pink-500 to-rose-500",
    },
    {
      id: "need-walker",
      title: "Need a Walker/Sitter",
      description: "Find trusted professionals to care for your pet",
      icon: Briefcase,
      color: "from-emerald-500 to-teal-500",
    },
    {
      id: "walker",
      title: "I'm a Walker/Sitter",
      description: "Offer your services to pet owners",
      icon: Users,
      color: "from-blue-500 to-indigo-500",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-white to-green-50 flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        {/* Logo */}
        <div className="flex justify-center mb-8">
          <img src={APP_LOGO} alt="PawMatch" className="h-40 w-auto" />
        </div>

        {/* Title */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-3">
            Welcome to PawMatch!
          </h1>
          <p className="text-lg text-gray-600">
            How would you like to use PawMatch today?
          </p>
        </div>

        {/* User Type Cards */}
        <div className="grid gap-4 mb-8">
          {userTypes.map((type) => {
            const Icon = type.icon;
            const isSelected = selectedType === type.id;

            return (
              <Card
                key={type.id}
                className={`p-6 cursor-pointer transition-all duration-200 ${
                  isSelected
                    ? "ring-4 ring-primary shadow-xl scale-[1.02]"
                    : "hover:shadow-lg hover:scale-[1.01]"
                }`}
                onClick={() => setSelectedType(type.id)}
              >
                <div className="flex items-start gap-4">
                  <div
                    className={`p-3 rounded-xl bg-gradient-to-br ${type.color} text-white`}
                  >
                    <Icon className="h-6 w-6" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold text-gray-900 mb-1">
                      {type.title}
                    </h3>
                    <p className="text-gray-600">{type.description}</p>
                  </div>
                  {isSelected && (
                    <div className="flex-shrink-0">
                      <div className="h-6 w-6 rounded-full bg-primary flex items-center justify-center">
                        <svg
                          className="h-4 w-4 text-white"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={3}
                            d="M5 13l4 4L19 7"
                          />
                        </svg>
                      </div>
                    </div>
                  )}
                </div>
              </Card>
            );
          })}
        </div>

        {/* Continue Button */}
        <Button
          onClick={handleContinue}
          disabled={!selectedType}
          className="w-full h-14 text-lg font-semibold"
          size="lg"
        >
          Continue to Discovery
        </Button>

        {/* Skip for now */}
        <div className="text-center mt-4">
          <button
            onClick={() => setLocation("/discover")}
            className="text-sm text-gray-500 hover:text-gray-700 underline"
          >
            Skip for now
          </button>
        </div>
      </div>
    </div>
  );
}
