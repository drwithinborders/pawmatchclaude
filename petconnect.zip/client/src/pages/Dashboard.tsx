import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { 
  PawPrint, 
  Briefcase, 
  Calendar, 
  Plus,
  Edit,
  Trash2,
  MapPin,
  Clock,
  Users
} from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";

export default function Dashboard() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const utils = trpc.useUtils();

  const { data: myPets = [], isLoading: petsLoading } = trpc.pets.myPets.useQuery();
  const { data: walkerProfile } = trpc.walkers.myProfile.useQuery();
  const { data: myMeetups = [] } = trpc.meetups.myMeetups.useQuery();
  const { data: joinedMeetups = [] } = trpc.meetups.joined.useQuery();

  const deletePet = trpc.pets.delete.useMutation({
    onSuccess: () => {
      utils.pets.myPets.invalidate();
      toast.success("Pet profile deleted successfully");
    },
    onError: (error) => {
      toast.error("Failed to delete pet profile");
    },
  });

  const deleteMeetup = trpc.meetups.delete.useMutation({
    onSuccess: () => {
      utils.meetups.myMeetups.invalidate();
      toast.success("Meetup deleted successfully");
    },
    onError: () => {
      toast.error("Failed to delete meetup");
    },
  });

  const leaveMeetup = trpc.meetups.leave.useMutation({
    onSuccess: () => {
      utils.meetups.joined.invalidate();
      toast.success("Left meetup successfully");
    },
    onError: () => {
      toast.error("Failed to leave meetup");
    },
  });

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold">Dashboard</h1>
              <p className="text-muted-foreground mt-1">Welcome back, {user?.name || "Friend"}!</p>
            </div>
            <Button variant="outline" onClick={() => setLocation("/")}>
              Back to Home
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="container py-8">
        <Tabs defaultValue="pets" className="w-full">
          <TabsList className="grid w-full max-w-2xl grid-cols-3 mx-auto mb-8">
            <TabsTrigger value="pets">
              <PawPrint className="h-4 w-4 mr-2" />
              My Pets
            </TabsTrigger>
            <TabsTrigger value="walker">
              <Briefcase className="h-4 w-4 mr-2" />
              Walker Profile
            </TabsTrigger>
            <TabsTrigger value="meetups">
              <Calendar className="h-4 w-4 mr-2" />
              Meetups
            </TabsTrigger>
          </TabsList>

          {/* My Pets Tab */}
          <TabsContent value="pets" className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold">My Pet Profiles</h2>
                <p className="text-muted-foreground">Manage your furry friends</p>
              </div>
              <Button onClick={() => toast("Create pet form coming soon!")}>
                <Plus className="h-4 w-4 mr-2" />
                Add Pet
              </Button>
            </div>

            {petsLoading ? (
              <div className="text-center py-12">Loading your pets...</div>
            ) : myPets.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <PawPrint className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No pets yet</h3>
                  <p className="text-muted-foreground mb-4">Add your first pet to start connecting with others</p>
                  <Button onClick={() => toast("Create pet form coming soon!")}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Your First Pet
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {myPets.map((pet) => (
                  <Card key={pet.id}>
                    <CardHeader>
                      {pet.imageUrl && (
                        <img 
                          src={pet.imageUrl} 
                          alt={pet.name}
                          className="w-full h-48 object-cover rounded-lg mb-4"
                        />
                      )}
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle>{pet.name}</CardTitle>
                          <CardDescription>{pet.breed || "Mixed breed"}</CardDescription>
                        </div>
                        <Badge variant="outline" className="capitalize">
                          {pet.energyLevel || "medium"}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {pet.age && (
                        <p className="text-sm text-muted-foreground">{pet.age} years old</p>
                      )}
                      {pet.about && (
                        <p className="text-sm line-clamp-3">{pet.about}</p>
                      )}
                      <div className="flex gap-2">
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="flex-1"
                          onClick={() => toast("Edit form coming soon!")}
                        >
                          <Edit className="h-4 w-4 mr-1" />
                          Edit
                        </Button>
                        <Button 
                          size="sm" 
                          variant="destructive" 
                          onClick={() => {
                            if (confirm("Are you sure you want to delete this pet profile?")) {
                              deletePet.mutate({ id: pet.id });
                            }
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Walker Profile Tab */}
          <TabsContent value="walker" className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold">Walker/Sitter Profile</h2>
                <p className="text-muted-foreground">Offer your professional pet care services</p>
              </div>
              {!walkerProfile && (
                <Button onClick={() => toast("Create walker profile form coming soon!")}>
                  <Plus className="h-4 w-4 mr-2" />
                  Create Profile
                </Button>
              )}
            </div>

            {walkerProfile ? (
              <Card>
                <CardHeader>
                  {walkerProfile.imageUrl && (
                    <img 
                      src={walkerProfile.imageUrl} 
                      alt={walkerProfile.businessName}
                      className="w-full h-64 object-cover rounded-lg mb-4"
                    />
                  )}
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-2xl">{walkerProfile.businessName}</CardTitle>
                      <CardDescription className="flex items-center gap-2 mt-2">
                        <MapPin className="h-4 w-4" />
                        {walkerProfile.location || "Location not set"}
                      </CardDescription>
                    </div>
                    <div className="flex gap-2">
                      {walkerProfile.verified && (
                        <Badge variant="secondary">Verified</Badge>
                      )}
                      <Badge variant="outline">
                        ⭐ {((walkerProfile.rating || 0) / 10).toFixed(1)}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {walkerProfile.about && (
                    <div>
                      <h4 className="font-semibold mb-2">About</h4>
                      <p className="text-muted-foreground">{walkerProfile.about}</p>
                    </div>
                  )}
                  {walkerProfile.pricePerWalk && (
                    <div>
                      <h4 className="font-semibold mb-2">Pricing</h4>
                      <p className="text-lg font-bold text-primary">
                        ${(walkerProfile.pricePerWalk / 100).toFixed(0)} per walk
                      </p>
                    </div>
                  )}
                  {walkerProfile.services && (
                    <div>
                      <h4 className="font-semibold mb-2">Services</h4>
                      <div className="flex flex-wrap gap-2">
                        {JSON.parse(walkerProfile.services).map((service: string, idx: number) => (
                          <Badge key={idx} variant="outline">{service}</Badge>
                        ))}
                      </div>
                    </div>
                  )}
                  <div className="flex gap-2 pt-4">
                    <Button 
                      variant="outline" 
                      className="flex-1"
                      onClick={() => toast("Edit form coming soon!")}
                    >
                      <Edit className="h-4 w-4 mr-2" />
                      Edit Profile
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="py-12 text-center">
                  <Briefcase className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No walker profile yet</h3>
                  <p className="text-muted-foreground mb-4">
                    Create a professional profile to offer pet walking and sitting services
                  </p>
                  <Button onClick={() => toast("Create walker profile form coming soon!")}>
                    <Plus className="h-4 w-4 mr-2" />
                    Create Walker Profile
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Meetups Tab */}
          <TabsContent value="meetups" className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold">My Meetups</h2>
                <p className="text-muted-foreground">Organize and join dog social events</p>
              </div>
              <Button onClick={() => toast("Create meetup form coming soon!")}>
                <Plus className="h-4 w-4 mr-2" />
                Create Meetup
              </Button>
            </div>

            {/* Organized Meetups */}
            <div>
              <h3 className="text-lg font-semibold mb-4">Meetups I'm Organizing</h3>
              {myMeetups.length === 0 ? (
                <Card>
                  <CardContent className="py-8 text-center">
                    <p className="text-muted-foreground">You haven't created any meetups yet</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid gap-4 md:grid-cols-2">
                  {myMeetups.map((meetup) => (
                    <Card key={meetup.id}>
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <CardTitle className="text-lg">{meetup.title}</CardTitle>
                            <CardDescription className="line-clamp-2">
                              {meetup.description || "No description"}
                            </CardDescription>
                          </div>
                          <Badge variant="outline" className="capitalize">
                            {meetup.activityType}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div className="flex items-center gap-2 text-sm">
                          <MapPin className="h-4 w-4 text-muted-foreground" />
                          <span>{meetup.location}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <Clock className="h-4 w-4 text-muted-foreground" />
                          <span>{new Date(meetup.meetupTime).toLocaleString()}</span>
                        </div>
                        <div className="flex gap-2">
                          <Button 
                            size="sm" 
                            variant="outline" 
                            className="flex-1"
                            onClick={() => toast("Edit form coming soon!")}
                          >
                            <Edit className="h-4 w-4 mr-1" />
                            Edit
                          </Button>
                          <Button 
                            size="sm" 
                            variant="destructive"
                            onClick={() => {
                              if (confirm("Are you sure you want to delete this meetup?")) {
                                deleteMeetup.mutate({ id: meetup.id });
                              }
                            }}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>

            {/* Joined Meetups */}
            <div>
              <h3 className="text-lg font-semibold mb-4">Meetups I've Joined</h3>
              {joinedMeetups.length === 0 ? (
                <Card>
                  <CardContent className="py-8 text-center">
                    <p className="text-muted-foreground">You haven't joined any meetups yet</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid gap-4 md:grid-cols-2">
                  {joinedMeetups.map((participant) => (
                    <Card key={participant.id}>
                      <CardContent className="py-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm text-muted-foreground">Meetup ID: {participant.meetupId}</p>
                            <p className="text-xs text-muted-foreground">
                              Joined: {new Date(participant.joinedAt).toLocaleDateString()}
                            </p>
                          </div>
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => {
                              if (confirm("Are you sure you want to leave this meetup?")) {
                                leaveMeetup.mutate({ meetupId: participant.meetupId });
                              }
                            }}
                          >
                            Leave
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
