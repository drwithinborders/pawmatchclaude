#!/usr/bin/env python3
"""
Facial Verification Service for PawMatch
Uses InsightFace to compare faces in two images and verify identity
"""

from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import insightface
from insightface.app import FaceAnalysis
import cv2
import numpy as np
from typing import Dict
import base64
import io
from PIL import Image

app = FastAPI(title="PawMatch Facial Verification Service")

# Enable CORS for local development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize InsightFace model
print("Loading InsightFace model...")
face_app = FaceAnalysis(providers=['CPUExecutionProvider'])
face_app.prepare(ctx_id=0, det_size=(640, 640))
print("Model loaded successfully")

def decode_image(image_data: bytes) -> np.ndarray:
    """Decode image from bytes to numpy array"""
    try:
        # Try to decode as base64 first
        if image_data.startswith(b'data:image'):
            # Remove data URL prefix
            image_data = image_data.split(b',')[1]
        
        try:
            image_data = base64.b64decode(image_data)
        except:
            pass  # Not base64, use as is
        
        # Convert to PIL Image then to numpy array
        pil_image = Image.open(io.BytesIO(image_data))
        # Convert to RGB if necessary
        if pil_image.mode != 'RGB':
            pil_image = pil_image.convert('RGB')
        # Convert to numpy array (OpenCV format: BGR)
        img = cv2.cvtColor(np.array(pil_image), cv2.COLOR_RGB2BGR)
        return img
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to decode image: {str(e)}")

def extract_face_embedding(img: np.ndarray) -> np.ndarray:
    """Extract face embedding from image"""
    faces = face_app.get(img)
    
    if len(faces) == 0:
        raise HTTPException(status_code=400, detail="No face detected in image")
    
    if len(faces) > 1:
        # If multiple faces, use the largest one
        faces = sorted(faces, key=lambda x: (x.bbox[2] - x.bbox[0]) * (x.bbox[3] - x.bbox[1]), reverse=True)
    
    # Return embedding of the first (or largest) face
    return faces[0].embedding

def compare_faces(embedding1: np.ndarray, embedding2: np.ndarray) -> float:
    """
    Compare two face embeddings and return similarity score
    Returns cosine similarity (0-1, higher is more similar)
    Tinder-like threshold: ~0.6 for verification
    """
    # Normalize embeddings
    embedding1 = embedding1 / np.linalg.norm(embedding1)
    embedding2 = embedding2 / np.linalg.norm(embedding2)
    
    # Calculate cosine similarity
    similarity = np.dot(embedding1, embedding2)
    
    return float(similarity)

@app.get("/")
async def root():
    return {
        "service": "PawMatch Facial Verification",
        "status": "running",
        "model": "InsightFace",
        "version": insightface.__version__
    }

@app.post("/verify")
async def verify_faces(
    profile_image: UploadFile = File(...),
    selfie_image: UploadFile = File(...)
) -> Dict:
    """
    Verify that two images contain the same person
    
    Args:
        profile_image: The user's profile photo
        selfie_image: The verification selfie
    
    Returns:
        {
            "verified": bool,
            "similarity": float (0-1),
            "threshold": float,
            "message": str
        }
    """
    try:
        # Read images
        profile_data = await profile_image.read()
        selfie_data = await selfie_image.read()
        
        # Decode images
        profile_img = decode_image(profile_data)
        selfie_img = decode_image(selfie_data)
        
        # Extract face embeddings
        try:
            profile_embedding = extract_face_embedding(profile_img)
        except HTTPException as e:
            raise HTTPException(status_code=400, detail=f"Profile image: {e.detail}")
        
        try:
            selfie_embedding = extract_face_embedding(selfie_img)
        except HTTPException as e:
            raise HTTPException(status_code=400, detail=f"Selfie image: {e.detail}")
        
        # Compare faces
        similarity = compare_faces(profile_embedding, selfie_embedding)
        
        # Verification threshold (similar to Tinder's approach)
        threshold = 0.6
        verified = similarity >= threshold
        
        return {
            "verified": verified,
            "similarity": round(similarity, 4),
            "threshold": threshold,
            "message": "Verification successful" if verified else "Faces do not match"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Verification failed: {str(e)}")

@app.post("/detect-face")
async def detect_face(image: UploadFile = File(...)) -> Dict:
    """
    Detect if an image contains a face
    Useful for validating images before upload
    """
    try:
        image_data = await image.read()
        img = decode_image(image_data)
        
        faces = face_app.get(img)
        
        return {
            "face_detected": len(faces) > 0,
            "face_count": len(faces),
            "message": f"Detected {len(faces)} face(s)" if len(faces) > 0 else "No face detected"
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Face detection failed: {str(e)}")

if __name__ == "__main__":
    import uvicorn
    print("Starting PawMatch Facial Verification Service on port 8001...")
    uvicorn.run(app, host="0.0.0.0", port=8001)
