CREATE TABLE `encounters` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user1Id` int NOT NULL,
	`user2Id` int NOT NULL,
	`encounteredAt` timestamp NOT NULL DEFAULT (now()),
	`location` varchar(200),
	CONSTRAINT `encounters_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `liveLocations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`latitude` varchar(20) NOT NULL,
	`longitude` varchar(20) NOT NULL,
	`isWalking` boolean DEFAULT false,
	`lastUpdated` timestamp NOT NULL DEFAULT (now()),
	`expiresAt` timestamp NOT NULL,
	CONSTRAINT `liveLocations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `matches` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user1Id` int NOT NULL,
	`user2Id` int NOT NULL,
	`matchedAt` timestamp NOT NULL DEFAULT (now()),
	`status` enum('active','unmatched') DEFAULT 'active',
	CONSTRAINT `matches_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `meetingReviews` (
	`id` int AUTO_INCREMENT NOT NULL,
	`reviewerId` int NOT NULL,
	`reviewedUserId` int NOT NULL,
	`meetingType` enum('playdate','walk','sitting','other') NOT NULL,
	`rating` int NOT NULL,
	`comment` text,
	`successful` boolean DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `meetingReviews_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`matchId` int NOT NULL,
	`senderId` int NOT NULL,
	`messageType` enum('text','photo') DEFAULT 'text',
	`content` text,
	`sentAt` timestamp NOT NULL DEFAULT (now()),
	`readAt` timestamp,
	CONSTRAINT `messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `verificationDocuments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`walkerId` int NOT NULL,
	`documentType` enum('malta_registration','cpd_first_aid','insurance','other') NOT NULL,
	`documentUrl` text NOT NULL,
	`status` enum('pending','approved','rejected') DEFAULT 'pending',
	`uploadedAt` timestamp NOT NULL DEFAULT (now()),
	`verifiedAt` timestamp,
	`verifiedBy` int,
	`notes` text,
	CONSTRAINT `verificationDocuments_id` PRIMARY KEY(`id`)
);
