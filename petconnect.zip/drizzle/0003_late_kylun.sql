ALTER TABLE `users` ADD `photoVerified` boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE `users` ADD `verifiedAt` timestamp;