CREATE TABLE `meetupParticipants` (
	`id` int AUTO_INCREMENT NOT NULL,
	`meetupId` int NOT NULL,
	`userId` int NOT NULL,
	`petId` int,
	`status` enum('joined','left','cancelled') DEFAULT 'joined',
	`joinedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `meetupParticipants_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `meetups` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizerId` int NOT NULL,
	`petId` int,
	`title` varchar(200) NOT NULL,
	`description` text,
	`location` varchar(200) NOT NULL,
	`meetupTime` timestamp NOT NULL,
	`duration` int,
	`maxParticipants` int,
	`activityType` enum('walk','playdate','training','hiking','swimming','other') DEFAULT 'walk',
	`energyLevel` enum('low','medium','high','very_high') DEFAULT 'medium',
	`status` enum('upcoming','completed','cancelled') DEFAULT 'upcoming',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `meetups_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `pets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(100) NOT NULL,
	`breed` varchar(100),
	`age` int,
	`energyLevel` enum('low','medium','high','very_high') DEFAULT 'medium',
	`interests` text,
	`about` text,
	`imageUrl` text,
	`availableTimes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `pets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `reviews` (
	`id` int AUTO_INCREMENT NOT NULL,
	`walkerId` int NOT NULL,
	`userId` int NOT NULL,
	`rating` int NOT NULL,
	`comment` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `reviews_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `walkers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`businessName` varchar(200) NOT NULL,
	`about` text,
	`imageUrl` text,
	`location` varchar(200),
	`certifications` text,
	`services` text,
	`pricePerWalk` int,
	`availability` text,
	`verified` boolean DEFAULT false,
	`rating` int DEFAULT 0,
	`reviewCount` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `walkers_id` PRIMARY KEY(`id`)
);
