import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  photoVerified: boolean("photoVerified").default(false),
  verifiedAt: timestamp("verifiedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Pet profiles - dogs looking for playdates and walking partners
 */
export const pets = mysqlTable("pets", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 100 }).notNull(),
  breed: varchar("breed", { length: 100 }),
  age: int("age"),
  energyLevel: mysqlEnum("energyLevel", ["low", "medium", "high", "very_high"]).default("medium"),
  interests: text("interests"), // JSON array of interests
  about: text("about"),
  imageUrl: text("imageUrl"),
  availableTimes: text("availableTimes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Pet = typeof pets.$inferSelect;
export type InsertPet = typeof pets.$inferInsert;

/**
 * Walker/Sitter profiles - verified professionals offering pet care services
 */
export const walkers = mysqlTable("walkers", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  businessName: varchar("businessName", { length: 200 }).notNull(),
  about: text("about"),
  imageUrl: text("imageUrl"),
  location: varchar("location", { length: 200 }),
  certifications: text("certifications"), // JSON array of certifications
  services: text("services"), // JSON array of services offered
  pricePerWalk: int("pricePerWalk"), // in cents to avoid decimal issues
  availability: text("availability"),
  verified: boolean("verified").default(false),
  rating: int("rating").default(0), // Store as integer (e.g., 49 for 4.9), divide by 10 for display
  reviewCount: int("reviewCount").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Walker = typeof walkers.$inferSelect;
export type InsertWalker = typeof walkers.$inferInsert;

/**
 * Meetup events - organized dog walks and playdates
 */
export const meetups = mysqlTable("meetups", {
  id: int("id").autoincrement().primaryKey(),
  organizerId: int("organizerId").notNull(), // user who created the meetup
  petId: int("petId"), // optional: specific pet for this meetup
  title: varchar("title", { length: 200 }).notNull(),
  description: text("description"),
  location: varchar("location", { length: 200 }).notNull(),
  meetupTime: timestamp("meetupTime").notNull(),
  duration: int("duration"), // in minutes
  maxParticipants: int("maxParticipants"),
  activityType: mysqlEnum("activityType", ["walk", "playdate", "training", "hiking", "swimming", "other"]).default("walk"),
  energyLevel: mysqlEnum("energyLevel", ["low", "medium", "high", "very_high"]).default("medium"),
  status: mysqlEnum("status", ["upcoming", "completed", "cancelled"]).default("upcoming"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Meetup = typeof meetups.$inferSelect;
export type InsertMeetup = typeof meetups.$inferInsert;

/**
 * Meetup participants - track who's joining which meetups
 */
export const meetupParticipants = mysqlTable("meetupParticipants", {
  id: int("id").autoincrement().primaryKey(),
  meetupId: int("meetupId").notNull(),
  userId: int("userId").notNull(),
  petId: int("petId"), // which pet is attending
  status: mysqlEnum("status", ["joined", "left", "cancelled"]).default("joined"),
  joinedAt: timestamp("joinedAt").defaultNow().notNull(),
});

export type MeetupParticipant = typeof meetupParticipants.$inferSelect;
export type InsertMeetupParticipant = typeof meetupParticipants.$inferInsert;

/**
 * Reviews for walkers/sitters
 */
export const reviews = mysqlTable("reviews", {
  id: int("id").autoincrement().primaryKey(),
  walkerId: int("walkerId").notNull(),
  userId: int("userId").notNull(), // reviewer
  rating: int("rating").notNull(), // 1-5 stars, stored as 10-50 for precision
  comment: text("comment"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Review = typeof reviews.$inferSelect;
export type InsertReview = typeof reviews.$inferInsert;

/**
 * Verification documents for walkers/sitters (Malta registration, CPD certificates)
 */
export const verificationDocuments = mysqlTable("verificationDocuments", {
  id: int("id").autoincrement().primaryKey(),
  walkerId: int("walkerId").notNull(),
  documentType: mysqlEnum("documentType", ["malta_registration", "cpd_first_aid", "insurance", "other"]).notNull(),
  documentUrl: text("documentUrl").notNull(),
  status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending"),
  uploadedAt: timestamp("uploadedAt").defaultNow().notNull(),
  verifiedAt: timestamp("verifiedAt"),
  verifiedBy: int("verifiedBy"), // admin user who verified
  notes: text("notes"),
});

export type VerificationDocument = typeof verificationDocuments.$inferSelect;
export type InsertVerificationDocument = typeof verificationDocuments.$inferInsert;

/**
 * Matches between users (for messaging)
 */
export const matches = mysqlTable("matches", {
  id: int("id").autoincrement().primaryKey(),
  user1Id: int("user1Id").notNull(),
  user2Id: int("user2Id").notNull(),
  matchedAt: timestamp("matchedAt").defaultNow().notNull(),
  status: mysqlEnum("status", ["active", "unmatched"]).default("active"),
});

export type Match = typeof matches.$inferSelect;
export type InsertMatch = typeof matches.$inferInsert;

/**
 * Chat messages between matched users
 */
export const messages = mysqlTable("messages", {
  id: int("id").autoincrement().primaryKey(),
  matchId: int("matchId").notNull(),
  senderId: int("senderId").notNull(),
  messageType: mysqlEnum("messageType", ["text", "photo"]).default("text"),
  content: text("content"), // text message or photo URL
  sentAt: timestamp("sentAt").defaultNow().notNull(),
  readAt: timestamp("readAt"),
});

export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;

/**
 * Live locations for active walkers (Happn-style feature)
 */
export const liveLocations = mysqlTable("liveLocations", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  latitude: varchar("latitude", { length: 20 }).notNull(),
  longitude: varchar("longitude", { length: 20 }).notNull(),
  isWalking: boolean("isWalking").default(false),
  lastUpdated: timestamp("lastUpdated").defaultNow().notNull(),
  expiresAt: timestamp("expiresAt").notNull(), // location expires after some time
});

export type LiveLocation = typeof liveLocations.$inferSelect;
export type InsertLiveLocation = typeof liveLocations.$inferInsert;

/**
 * Encounters - track when users pass by each other (Happn-style)
 */
export const encounters = mysqlTable("encounters", {
  id: int("id").autoincrement().primaryKey(),
  user1Id: int("user1Id").notNull(),
  user2Id: int("user2Id").notNull(),
  encounteredAt: timestamp("encounteredAt").defaultNow().notNull(),
  location: varchar("location", { length: 200 }), // general area like "Valletta"
});

export type Encounter = typeof encounters.$inferSelect;
export type InsertEncounter = typeof encounters.$inferInsert;

/**
 * Meeting reviews - reviews after successful meetups or service bookings
 */
export const meetingReviews = mysqlTable("meetingReviews", {
  id: int("id").autoincrement().primaryKey(),
  reviewerId: int("reviewerId").notNull(),
  reviewedUserId: int("reviewedUserId").notNull(),
  meetingType: mysqlEnum("meetingType", ["playdate", "walk", "sitting", "other"]).notNull(),
  rating: int("rating").notNull(), // 1-5 stars
  comment: text("comment"),
  successful: boolean("successful").default(true), // success badge
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type MeetingReview = typeof meetingReviews.$inferSelect;
export type InsertMeetingReview = typeof meetingReviews.$inferInsert;
