import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Pet profile management
  pets: router({
    list: publicProcedure.query(async () => {
      return db.getAllPets();
    }),
    
    myPets: protectedProcedure.query(async ({ ctx }) => {
      return db.getPetsByUserId(ctx.user.id);
    }),
    
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return db.getPetById(input.id);
      }),
    
    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1),
        breed: z.string().optional(),
        age: z.number().optional(),
        energyLevel: z.enum(["low", "medium", "high", "very_high"]).optional(),
        interests: z.string().optional(), // JSON string
        about: z.string().optional(),
        imageUrl: z.string().optional(),
        availableTimes: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        return db.createPet({
          userId: ctx.user.id,
          ...input,
        });
      }),
    
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().min(1).optional(),
        breed: z.string().optional(),
        age: z.number().optional(),
        energyLevel: z.enum(["low", "medium", "high", "very_high"]).optional(),
        interests: z.string().optional(),
        about: z.string().optional(),
        imageUrl: z.string().optional(),
        availableTimes: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { id, ...updates } = input;
        return db.updatePet(id, ctx.user.id, updates);
      }),
    
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        return db.deletePet(input.id, ctx.user.id);
      }),
  }),

  // Walker/Sitter profile management
  walkers: router({
    list: publicProcedure.query(async () => {
      return db.getAllWalkers();
    }),
    
    myProfile: protectedProcedure.query(async ({ ctx }) => {
      return db.getWalkerByUserId(ctx.user.id);
    }),
    
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return db.getWalkerById(input.id);
      }),
    
    create: protectedProcedure
      .input(z.object({
        businessName: z.string().min(1),
        about: z.string().optional(),
        imageUrl: z.string().optional(),
        location: z.string().optional(),
        certifications: z.string().optional(), // JSON string
        services: z.string().optional(), // JSON string
        pricePerWalk: z.number().optional(),
        availability: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        return db.createWalker({
          userId: ctx.user.id,
          verified: false,
          rating: 0,
          reviewCount: 0,
          ...input,
        });
      }),
    
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        businessName: z.string().min(1).optional(),
        about: z.string().optional(),
        imageUrl: z.string().optional(),
        location: z.string().optional(),
        certifications: z.string().optional(),
        services: z.string().optional(),
        pricePerWalk: z.number().optional(),
        availability: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { id, ...updates } = input;
        return db.updateWalker(id, ctx.user.id, updates);
      }),
    
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        return db.deleteWalker(input.id, ctx.user.id);
      }),
  }),

  // Meetup management
  meetups: router({
    upcoming: publicProcedure.query(async () => {
      return db.getUpcomingMeetups();
    }),
    
    myMeetups: protectedProcedure.query(async ({ ctx }) => {
      return db.getMeetupsByOrganizer(ctx.user.id);
    }),
    
    joined: protectedProcedure.query(async ({ ctx }) => {
      return db.getUserMeetups(ctx.user.id);
    }),
    
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return db.getMeetupById(input.id);
      }),
    
    participants: publicProcedure
      .input(z.object({ meetupId: z.number() }))
      .query(async ({ input }) => {
        return db.getMeetupParticipants(input.meetupId);
      }),
    
    create: protectedProcedure
      .input(z.object({
        petId: z.number().optional(),
        title: z.string().min(1),
        description: z.string().optional(),
        location: z.string().min(1),
        meetupTime: z.date(),
        duration: z.number().optional(),
        maxParticipants: z.number().optional(),
        activityType: z.enum(["walk", "playdate", "training", "hiking", "swimming", "other"]).optional(),
        energyLevel: z.enum(["low", "medium", "high", "very_high"]).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        return db.createMeetup({
          organizerId: ctx.user.id,
          status: 'upcoming',
          ...input,
        });
      }),
    
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().min(1).optional(),
        description: z.string().optional(),
        location: z.string().optional(),
        meetupTime: z.date().optional(),
        duration: z.number().optional(),
        maxParticipants: z.number().optional(),
        activityType: z.enum(["walk", "playdate", "training", "hiking", "swimming", "other"]).optional(),
        energyLevel: z.enum(["low", "medium", "high", "very_high"]).optional(),
        status: z.enum(["upcoming", "completed", "cancelled"]).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { id, ...updates } = input;
        return db.updateMeetup(id, ctx.user.id, updates);
      }),
    
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        return db.deleteMeetup(input.id, ctx.user.id);
      }),
    
    join: protectedProcedure
      .input(z.object({
        meetupId: z.number(),
        petId: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        return db.joinMeetup({
          meetupId: input.meetupId,
          userId: ctx.user.id,
          petId: input.petId,
          status: 'joined',
        });
      }),
    
    leave: protectedProcedure
      .input(z.object({ meetupId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        return db.leaveMeetup(input.meetupId, ctx.user.id);
      }),
  }),

  // Reviews
  reviews: router({
    byWalker: publicProcedure
      .input(z.object({ walkerId: z.number() }))
      .query(async ({ input }) => {
        return db.getWalkerReviews(input.walkerId);
      }),
    
    myReviews: protectedProcedure.query(async ({ ctx }) => {
      return db.getUserReviews(ctx.user.id);
    }),
    
    create: protectedProcedure
      .input(z.object({
        walkerId: z.number(),
        rating: z.number().min(10).max(50), // 1.0 to 5.0 stars stored as 10-50
        comment: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        return db.createReview({
          walkerId: input.walkerId,
          userId: ctx.user.id,
          rating: input.rating,
          comment: input.comment,
        });
      }),
  }),

  // Matches and messaging
  matches: router({
    create: protectedProcedure
      .input(z.object({ targetUserId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        return db.createMatch(ctx.user.id, input.targetUserId);
      }),
    
    myMatches: protectedProcedure.query(async ({ ctx }) => {
      return db.getMatchesByUserId(ctx.user.id);
    }),
    
    checkMatch: protectedProcedure
      .input(z.object({ targetUserId: z.number() }))
      .query(async ({ ctx, input }) => {
        return db.checkMatch(ctx.user.id, input.targetUserId);
      }),
  }),

  messages: router({
    send: protectedProcedure
      .input(z.object({
        matchId: z.number(),
        content: z.string(),
        messageType: z.enum(["text", "photo"]).default("text"),
      }))
      .mutation(async ({ ctx, input }) => {
        return db.createMessage(input.matchId, ctx.user.id, input.content, input.messageType);
      }),
    
    getByMatchId: protectedProcedure
      .input(z.object({ matchId: z.number() }))
      .query(async ({ input }) => {
        return db.getMessagesByMatchId(input.matchId);
      }),
  }),

  // Live location tracking (Happn-style)
  locations: router({
    updateLocation: protectedProcedure
      .input(z.object({
        latitude: z.string(),
        longitude: z.string(),
        isWalking: z.boolean().default(false),
      }))
      .mutation(async ({ ctx, input }) => {
        return db.updateLiveLocation(ctx.user.id, input.latitude, input.longitude, input.isWalking);
      }),
    
    getActiveWalkers: publicProcedure.query(async () => {
      return db.getActiveLiveLocations();
    }),
  }),

  // Encounters (passed by feature)
  encounters: router({
    record: protectedProcedure
      .input(z.object({
        targetUserId: z.number(),
        location: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        return db.recordEncounter(ctx.user.id, input.targetUserId, input.location);
      }),
    
    getCount: protectedProcedure
      .input(z.object({ targetUserId: z.number() }))
      .query(async ({ ctx, input }) => {
        return db.getEncounterCount(ctx.user.id, input.targetUserId);
      }),
  }),

  // Verification documents
  verification: router({
    uploadDocument: protectedProcedure
      .input(z.object({
        walkerId: z.number(),
        documentType: z.enum(["malta_registration", "cpd_first_aid", "insurance", "other"]),
        documentUrl: z.string(),
      }))
      .mutation(async ({ input }) => {
        return db.uploadVerificationDocument(input.walkerId, input.documentType, input.documentUrl);
      }),
    
    getDocuments: protectedProcedure
      .input(z.object({ walkerId: z.number() }))
      .query(async ({ input }) => {
        return db.getVerificationDocumentsByWalkerId(input.walkerId);
      }),
  }),

  // Meeting reviews
  meetingReviews: router({
    create: protectedProcedure
      .input(z.object({
        reviewedUserId: z.number(),
        meetingType: z.enum(["playdate", "walk", "sitting", "other"]),
        rating: z.number().min(1).max(5),
        comment: z.string(),
        successful: z.boolean().default(true),
      }))
      .mutation(async ({ ctx, input }) => {
        return db.createMeetingReview(
          ctx.user.id,
          input.reviewedUserId,
          input.meetingType,
          input.rating,
          input.comment,
          input.successful
        );
      }),
    
    getByUserId: publicProcedure
      .input(z.object({ userId: z.number() }))
      .query(async ({ input }) => {
        return db.getMeetingReviewsByUserId(input.userId);
      }),
  }),
});

export type AppRouter = typeof appRouter;
