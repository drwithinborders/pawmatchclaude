import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(userId: number = 1): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: userId,
    openId: `test-user-${userId}`,
    email: `user${userId}@example.com`,
    name: `Test User ${userId}`,
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return { ctx };
}

describe("pets router", () => {
  it("allows authenticated users to create a pet profile", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.pets.create({
      name: "Buddy",
      breed: "Golden Retriever",
      age: 3,
      energyLevel: "high",
      about: "Friendly and loves to play",
    });

    expect(result).toBeDefined();
  });

  it("allows users to list all pets publicly", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const pets = await caller.pets.list();
    expect(Array.isArray(pets)).toBe(true);
  });

  it("allows authenticated users to view their own pets", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const myPets = await caller.pets.myPets();
    expect(Array.isArray(myPets)).toBe(true);
  });
});

describe("walkers router", () => {
  it("allows authenticated users to create a walker profile", async () => {
    const { ctx } = createAuthContext(2);
    const caller = appRouter.createCaller(ctx);

    const result = await caller.walkers.create({
      businessName: "Happy Paws Walking",
      about: "Professional dog walker with 5 years experience",
      location: "Portland, OR",
      pricePerWalk: 2500, // $25.00
      services: JSON.stringify(["Dog Walking", "Pet Sitting", "Group Walks"]),
    });

    expect(result).toBeDefined();
  });

  it("allows users to list all walkers publicly", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const walkers = await caller.walkers.list();
    expect(Array.isArray(walkers)).toBe(true);
  });
});

describe("meetups router", () => {
  it("allows authenticated users to create a meetup", async () => {
    const { ctx } = createAuthContext(3);
    const caller = appRouter.createCaller(ctx);

    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);

    const result = await caller.meetups.create({
      title: "Morning Park Walk",
      description: "Casual walk in the park",
      location: "Central Park",
      meetupTime: tomorrow,
      activityType: "walk",
      energyLevel: "medium",
    });

    expect(result).toBeDefined();
  });

  it("allows users to view upcoming meetups publicly", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const meetups = await caller.meetups.upcoming();
    expect(Array.isArray(meetups)).toBe(true);
  });
});
