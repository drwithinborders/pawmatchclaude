/**
 * Facial Verification Helper
 * Calls the Python InsightFace service to verify faces
 */

import FormData from 'form-data';
import fetch from 'node-fetch';

const FACIAL_SERVICE_URL = 'http://localhost:8001';

export interface FacialVerificationResult {
  verified: boolean;
  similarity: number;
  threshold: number;
  message: string;
}

export interface FaceDetectionResult {
  face_detected: boolean;
  face_count: number;
  message: string;
}

/**
 * Verify that two images contain the same person
 * @param profileImageBuffer - Buffer of the profile photo
 * @param selfieImageBuffer - Buffer of the verification selfie
 * @returns Verification result with similarity score
 */
export async function verifyFaces(
  profileImageBuffer: Buffer,
  selfieImageBuffer: Buffer
): Promise<FacialVerificationResult> {
  try {
    const formData = new FormData();
    formData.append('profile_image', profileImageBuffer, {
      filename: 'profile.jpg',
      contentType: 'image/jpeg',
    });
    formData.append('selfie_image', selfieImageBuffer, {
      filename: 'selfie.jpg',
      contentType: 'image/jpeg',
    });

    const response = await fetch(`${FACIAL_SERVICE_URL}/verify`, {
      method: 'POST',
      body: formData,
      headers: formData.getHeaders(),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail || 'Facial verification failed');
    }

    const result = await response.json() as FacialVerificationResult;
    return result;
  } catch (error) {
    console.error('[Facial Verification] Error:', error);
    throw new Error(`Facial verification service error: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

/**
 * Detect if an image contains a face
 * @param imageBuffer - Buffer of the image to check
 * @returns Detection result
 */
export async function detectFace(imageBuffer: Buffer): Promise<FaceDetectionResult> {
  try {
    const formData = new FormData();
    formData.append('image', imageBuffer, {
      filename: 'image.jpg',
      contentType: 'image/jpeg',
    });

    const response = await fetch(`${FACIAL_SERVICE_URL}/detect-face`, {
      method: 'POST',
      body: formData,
      headers: formData.getHeaders(),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail || 'Face detection failed');
    }

    const result = await response.json() as FaceDetectionResult;
    return result;
  } catch (error) {
    console.error('[Face Detection] Error:', error);
    throw new Error(`Face detection service error: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

/**
 * Check if the facial verification service is running
 */
export async function checkServiceHealth(): Promise<boolean> {
  try {
    const response = await fetch(`${FACIAL_SERVICE_URL}/`);
    return response.ok;
  } catch {
    return false;
  }
}
