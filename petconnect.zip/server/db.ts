import { eq, or, and, gt, desc, gte, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, 
  users, 
  pets, 
  walkers, 
  meetups, 
  meetupParticipants, 
  reviews,
  matches,
  messages,
  liveLocations,
  encounters,
  verificationDocuments,
  meetingReviews,
  InsertPet,
  InsertWalker,
  InsertMeetup,
  InsertMeetupParticipant,
  InsertReview
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Pet profile queries
export async function createPet(pet: InsertPet) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(pets).values(pet);
  return result;
}

export async function updatePet(petId: number, userId: number, updates: Partial<InsertPet>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(pets)
    .set(updates)
    .where(and(eq(pets.id, petId), eq(pets.userId, userId)));
}

export async function getPetsByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(pets).where(eq(pets.userId, userId));
}

export async function getPetById(petId: number) {
  const db = await getDb();
  if (!db) return null;
  
  const result = await db.select().from(pets).where(eq(pets.id, petId)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getAllPets() {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(pets).orderBy(desc(pets.createdAt));
}

export async function deletePet(petId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(pets).where(and(eq(pets.id, petId), eq(pets.userId, userId)));
}

// Walker profile queries
export async function createWalker(walker: InsertWalker) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(walkers).values(walker);
  return result;
}

export async function updateWalker(walkerId: number, userId: number, updates: Partial<InsertWalker>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(walkers)
    .set(updates)
    .where(and(eq(walkers.id, walkerId), eq(walkers.userId, userId)));
}

export async function getWalkerByUserId(userId: number) {
  const db = await getDb();
  if (!db) return null;
  
  const result = await db.select().from(walkers).where(eq(walkers.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getWalkerById(walkerId: number) {
  const db = await getDb();
  if (!db) return null;
  
  const result = await db.select().from(walkers).where(eq(walkers.id, walkerId)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getAllWalkers() {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(walkers).orderBy(desc(walkers.rating));
}

export async function deleteWalker(walkerId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(walkers).where(and(eq(walkers.id, walkerId), eq(walkers.userId, userId)));
}

// Meetup queries
export async function createMeetup(meetup: InsertMeetup) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(meetups).values(meetup);
  return result;
}

export async function updateMeetup(meetupId: number, organizerId: number, updates: Partial<InsertMeetup>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(meetups)
    .set(updates)
    .where(and(eq(meetups.id, meetupId), eq(meetups.organizerId, organizerId)));
}

export async function getMeetupById(meetupId: number) {
  const db = await getDb();
  if (!db) return null;
  
  const result = await db.select().from(meetups).where(eq(meetups.id, meetupId)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getUpcomingMeetups() {
  const db = await getDb();
  if (!db) return [];
  
  const now = new Date();
  return db.select()
    .from(meetups)
    .where(and(
      eq(meetups.status, 'upcoming'),
      gte(meetups.meetupTime, now)
    ))
    .orderBy(meetups.meetupTime);
}

export async function getMeetupsByOrganizer(organizerId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(meetups).where(eq(meetups.organizerId, organizerId)).orderBy(desc(meetups.meetupTime));
}

export async function deleteMeetup(meetupId: number, organizerId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(meetups).where(and(eq(meetups.id, meetupId), eq(meetups.organizerId, organizerId)));
}

// Meetup participants queries
export async function joinMeetup(participant: InsertMeetupParticipant) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(meetupParticipants).values(participant);
  return result;
}

export async function leaveMeetup(meetupId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(meetupParticipants)
    .set({ status: 'left' })
    .where(and(
      eq(meetupParticipants.meetupId, meetupId),
      eq(meetupParticipants.userId, userId)
    ));
}

export async function getMeetupParticipants(meetupId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select()
    .from(meetupParticipants)
    .where(and(
      eq(meetupParticipants.meetupId, meetupId),
      eq(meetupParticipants.status, 'joined')
    ));
}

export async function getUserMeetups(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select()
    .from(meetupParticipants)
    .where(and(
      eq(meetupParticipants.userId, userId),
      eq(meetupParticipants.status, 'joined')
    ));
}

// Review queries
export async function createReview(review: InsertReview) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(reviews).values(review);
  
  // Update walker rating and review count
  const walkerReviews = await db.select().from(reviews).where(eq(reviews.walkerId, review.walkerId));
  const totalRating = walkerReviews.reduce((sum, r) => sum + r.rating, 0);
  const avgRating = Math.round(totalRating / walkerReviews.length);
  
  await db.update(walkers)
    .set({
      rating: avgRating,
      reviewCount: walkerReviews.length
    })
    .where(eq(walkers.id, review.walkerId));
  
  return result;
}

export async function getWalkerReviews(walkerId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(reviews).where(eq(reviews.walkerId, walkerId)).orderBy(desc(reviews.createdAt));
}

export async function getUserReviews(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(reviews).where(eq(reviews.userId, userId)).orderBy(desc(reviews.createdAt));
}

// ===== Matches =====
export async function createMatch(user1Id: number, user2Id: number) {
  const db = await getDb();
  if (!db) return null;
  
  const [match] = await db.insert(matches).values({
    user1Id,
    user2Id,
  });
  return match;
}

export async function getMatchesByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(matches).where(
    or(eq(matches.user1Id, userId), eq(matches.user2Id, userId))
  );
}

export async function checkMatch(user1Id: number, user2Id: number) {
  const db = await getDb();
  if (!db) return null;
  
  const result = await db.select().from(matches).where(
    or(
      and(eq(matches.user1Id, user1Id), eq(matches.user2Id, user2Id)),
      and(eq(matches.user1Id, user2Id), eq(matches.user2Id, user1Id))
    )
  ).limit(1);
  
  return result.length > 0 ? result[0] : null;
}

// ===== Messages =====
export async function createMessage(matchId: number, senderId: number, content: string, messageType: "text" | "photo" = "text") {
  const db = await getDb();
  if (!db) return null;
  
  await db.insert(messages).values({
    matchId,
    senderId,
    content,
    messageType,
  });
}

export async function getMessagesByMatchId(matchId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(messages).where(eq(messages.matchId, matchId)).orderBy(messages.sentAt);
}

// ===== Live Locations =====
export async function updateLiveLocation(userId: number, latitude: string, longitude: string, isWalking: boolean = false) {
  const db = await getDb();
  if (!db) return null;
  
  const expiresAt = new Date(Date.now() + 30 * 60 * 1000); // 30 minutes from now
  
  await db.insert(liveLocations).values({
    userId,
    latitude,
    longitude,
    isWalking,
    expiresAt,
  }).onDuplicateKeyUpdate({
    set: {
      latitude,
      longitude,
      isWalking,
      lastUpdated: new Date(),
      expiresAt,
    },
  });
}

export async function getActiveLiveLocations() {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(liveLocations).where(
    and(
      eq(liveLocations.isWalking, true),
      gt(liveLocations.expiresAt, new Date())
    )
  );
}

// ===== Encounters =====
export async function recordEncounter(user1Id: number, user2Id: number, location: string) {
  const db = await getDb();
  if (!db) return null;
  
  await db.insert(encounters).values({
    user1Id,
    user2Id,
    location,
  });
}

export async function getEncounterCount(user1Id: number, user2Id: number) {
  const db = await getDb();
  if (!db) return 0;
  
  const result = await db.select().from(encounters).where(
    or(
      and(eq(encounters.user1Id, user1Id), eq(encounters.user2Id, user2Id)),
      and(eq(encounters.user1Id, user2Id), eq(encounters.user2Id, user1Id))
    )
  );
  
  return result.length;
}

// ===== Verification Documents =====
export async function uploadVerificationDocument(walkerId: number, documentType: string, documentUrl: string) {
  const db = await getDb();
  if (!db) return null;
  
  await db.insert(verificationDocuments).values({
    walkerId,
    documentType: documentType as any,
    documentUrl,
  });
}

export async function getVerificationDocumentsByWalkerId(walkerId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(verificationDocuments).where(eq(verificationDocuments.walkerId, walkerId));
}

// ===== Meeting Reviews =====
export async function createMeetingReview(reviewerId: number, reviewedUserId: number, meetingType: string, rating: number, comment: string, successful: boolean = true) {
  const db = await getDb();
  if (!db) return null;
  
  await db.insert(meetingReviews).values({
    reviewerId,
    reviewedUserId,
    meetingType: meetingType as any,
    rating,
    comment,
    successful,
  });
}

export async function getMeetingReviewsByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(meetingReviews).where(eq(meetingReviews.reviewedUserId, userId));
}
