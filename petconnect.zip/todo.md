# PetConnect TODO

## Core Features

- [x] Database schema for pet profiles (name, breed, age, energy level, interests)
- [x] Database schema for walker profiles (certifications, pricing, availability, services)
- [x] Database schema for meetup events (location, time, participants)
- [x] Database schema for reviews and ratings
- [x] Backend API for creating and updating pet profiles
- [x] Backend API for creating and updating walker profiles
- [x] Backend API for discovering walkers with filters (location, price, availability)
- [x] Backend API for discovering dog meetups with filters (location, time, energy level)
- [x] Backend API for creating and joining meetup events
- [x] Backend API for reviews and ratings system
- [x] Frontend: Landing page with dual-purpose introduction
- [x] Frontend: Walker discovery tab with search and filters
- [x] Frontend: Dog meetups tab with search and filters
- [ ] Frontend: Walker profile detail page
- [ ] Frontend: Dog profile detail page
- [x] Frontend: User dashboard for managing own profiles
- [ ] Frontend: Create/edit pet profile form
- [ ] Frontend: Create/edit walker profile form
- [ ] Frontend: Meetup creation and management interface
- [ ] Frontend: Reviews and ratings display
- [x] Authentication flow integration
- [ ] Image upload for profiles (pets and walkers)
- [ ] Location-based search functionality
- [x] Responsive design for mobile devices

## Design Updates

- [x] Update color scheme to match PawMatch logo (red primary, green accent)
- [x] Integrate PawMatch logo into the application
- [x] Update branding from PetConnect to PawMatch

## Major Redesign (User Feedback)

- [x] Add dog breeds database/reference from FCI breeds CSV
- [x] Create seed data script with Malta-based demo users
- [x] Create demo pet profiles (Malta locations)
- [x] Create demo walker profiles (Malta locations)
- [x] Build onboarding flow with user type selection (pet owner vs walker/sitter)
- [x] Implement Tinder-style swipe discovery interface
- [x] Add card stack with swipe left/right gestures
- [x] Add filtering by user type (need walker/sitter vs find dog playmates)
- [ ] Support profile photos (pet only or user+pet)
- [x] Redesign UI inspired by Whiskr (cleaner, more polished)
- [ ] Implement smooth animations and transitions
- [x] Make discovery the primary interface (not tabs)

## New Features (User Feedback Round 2)

- [x] Walker verification system with document upload (Malta registration)
- [x] CPD qualifications upload for animal first aid)
- [ ] Verification badge display for verified walkers
- [x] Photo messaging in chat for check-ins
- [ ] Allow walkers to show premises photos
- [x] Post-meetup review system with success badges
- [x] Fix logo positioning and sizing
- [x] Import real demo dog images
- [x] Import real pet sitter profile images
- [ ] Live location map showing active walkers
- [ ] Hotspot map feature like Happn
- [ ] "Passed by X times" counter for nearby users
- [ ] Match requirement for pet owner to pet owner messaging
- [ ] Walker can offer both walking and sitting services
- [x] Database schema for verification documents
- [x] Database schema for photo messages
- [x] Database schema for live locations
- [x] Database schema for "passed by" encounters

## Facial Verification (Safety Feature)

- [x] Extract and set up InsightFace library
- [x] Create Python service for facial recognition comparison
- [x] Add API endpoint for facial verification
- [ ] Build selfie capture UI component
- [ ] Implement verification flow (profile photo + live selfie)
- [ ] Add verification badge display for verified users
- [ ] Store verification status in database

## UI Redesign (Critical)

- [ ] Completely redesign discovery cards with full-screen images like Whiskr
- [ ] Add smooth swipe animations and card transitions
- [ ] Improve card layout with better typography and spacing
- [ ] Add profile details overlay on cards
- [ ] Implement bottom navigation bar (Home, Discover, Messages, Profile)
- [ ] Create modern profile view pages
- [ ] Add image galleries for pet/walker profiles
- [ ] Improve color scheme and visual hierarchy
- [ ] Make UI more mobile-first and touch-friendly
