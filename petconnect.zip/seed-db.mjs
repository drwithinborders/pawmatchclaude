import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import { like } from "drizzle-orm";
import * as schema from "./drizzle/schema.js";

const DATABASE_URL = process.env.DATABASE_URL;

if (!DATABASE_URL) {
  console.error("DATABASE_URL environment variable is not set");
  process.exit(1);
}

const connection = await mysql.createConnection(DATABASE_URL);
const db = drizzle(connection, { schema, mode: "default" });

// Malta locations
const maltaLocations = [
  "Valletta, Malta",
  "Sliema, Malta",
  "St. Julian's, Malta",
  "Mdina, Malta",
  "Rabat, Malta",
  "Marsaxlokk, Malta",
  "Mellieħa, Malta",
  "Gozo, Malta",
  "Birżebbuġa, Malta",
  "Qawra, Malta",
];

// Demo users data
const demoUsers = [
  {
    openId: "malta-user-1",
    name: "Maria Borg",
    email: "maria.borg@example.mt",
    loginMethod: "manus",
    role: "user",
  },
  {
    openId: "malta-user-2",
    name: "John Camilleri",
    email: "john.camilleri@example.mt",
    loginMethod: "manus",
    role: "user",
  },
  {
    openId: "malta-user-3",
    name: "Sarah Vella",
    email: "sarah.vella@example.mt",
    loginMethod: "manus",
    role: "user",
  },
  {
    openId: "malta-user-4",
    name: "David Farrugia",
    email: "david.farrugia@example.mt",
    loginMethod: "manus",
    role: "user",
  },
  {
    openId: "malta-user-5",
    name: "Emma Zammit",
    email: "emma.zammit@example.mt",
    loginMethod: "manus",
    role: "user",
  },
  {
    openId: "malta-user-6",
    name: "Luke Azzopardi",
    email: "luke.azzopardi@example.mt",
    loginMethod: "manus",
    role: "user",
  },
  {
    openId: "malta-user-7",
    name: "Sophie Galea",
    email: "sophie.galea@example.mt",
    loginMethod: "manus",
    role: "user",
  },
  {
    openId: "malta-user-8",
    name: "Mark Grech",
    email: "mark.grech@example.mt",
    loginMethod: "manus",
    role: "user",
  },
];

console.log("Seeding demo users...");
for (const user of demoUsers) {
  await db.insert(schema.users).values(user).onDuplicateKeyUpdate({ set: { name: user.name } });
}

// Get user IDs
const users = await db.select().from(schema.users).where(like(schema.users.openId, 'malta-user-%'));
console.log(`Found ${users.length} demo users`);

// Demo pets
const demoPets = [
  {
    userId: users[0].id,
    name: "Bella",
    breed: "Golden Retriever",
    age: 3,
    energyLevel: "high",
    about: "Friendly and loves to play fetch at the beach!",
    interests: JSON.stringify(["Beach walks", "Swimming", "Fetch"]),
    photoUrl: "/demo/labrador-2.jpg",
  },
  {
    userId: users[1].id,
    name: "Max",
    breed: "Border Collie",
    age: 2,
    energyLevel: "high",
    about: "Super smart and loves agility training",
    interests: JSON.stringify(["Agility", "Running", "Training"]),
    photoUrl: "/demo/border-collie-1.jpg",
  },
  {
    userId: users[2].id,
    name: "Luna",
    breed: "Labrador Retriever",
    age: 4,
    energyLevel: "medium",
    about: "Gentle soul who loves meeting new friends",
    interests: JSON.stringify(["Socializing", "Treats", "Naps"]),
    photoUrl: "/demo/labrador-1.jpg",
  },
  {
    userId: users[3].id,
    name: "Charlie",
    breed: "Pug",
    age: 5,
    energyLevel: "low",
    about: "Loves short walks and lots of cuddles",
    interests: JSON.stringify(["Cuddles", "Short walks", "Food"]),
    photoUrl: "/demo/french-bulldog-1.jpg",
  },
  {
    userId: users[4].id,
    name: "Rocky",
    breed: "German Shepherd",
    age: 3,
    energyLevel: "high",
    about: "Protective and loyal, loves long hikes",
    interests: JSON.stringify(["Hiking", "Training", "Protection work"]),
    photoUrl: "/demo/border-collie-2.jpg",
  },
  {
    userId: users[5].id,
    name: "Daisy",
    breed: "Beagle",
    age: 2,
    energyLevel: "medium",
    about: "Curious and friendly, loves exploring",
    interests: JSON.stringify(["Sniffing", "Exploring", "Playing"]),
    photoUrl: "/demo/beagle-1.jpg",
  },
  {
    userId: users[6].id,
    name: "Milo",
    breed: "French Bulldog",
    age: 1,
    energyLevel: "medium",
    about: "Playful puppy looking for friends",
    interests: JSON.stringify(["Playing", "Socializing", "Toys"]),
    photoUrl: "https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=800",
  },
  {
    userId: users[7].id,
    name: "Coco",
    breed: "Cocker Spaniel",
    age: 6,
    energyLevel: "medium",
    about: "Sweet and gentle, great with kids",
    interests: JSON.stringify(["Kids", "Gentle play", "Walks"]),
    photoUrl: "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=800",
  },
];

console.log("Seeding demo pets...");
for (const pet of demoPets) {
  await db.insert(schema.pets).values(pet);
}

// Demo walkers
const demoWalkers = [
  {
    userId: users[0].id,
    businessName: "Paws & Walks Malta",
    about: "Professional dog walker with 5+ years experience. Certified in pet first aid.",
    location: maltaLocations[0],
    pricePerWalk: 1500, // €15
    availability: JSON.stringify(["Monday", "Wednesday", "Friday"]),
    services: JSON.stringify(["Dog Walking", "Pet Sitting", "Group Walks"]),
    certifications: JSON.stringify(["Pet First Aid", "Canine Behavior"]),
    photoUrl: "/demo/walker-1.jpg",
  },
  {
    userId: users[2].id,
    businessName: "Malta Pet Care Services",
    about: "Experienced pet sitter offering home visits and overnight care.",
    location: maltaLocations[1],
    pricePerWalk: 2000, // €20
    availability: JSON.stringify(["Tuesday", "Thursday", "Saturday", "Sunday"]),
    services: JSON.stringify(["Pet Sitting", "Home Visits", "Medication Administration"]),
    certifications: JSON.stringify(["Veterinary Assistant", "Pet First Aid"]),
    photoUrl: "/demo/walker-2.jpg",
  },
  {
    userId: users[4].id,
    businessName: "Happy Tails Walking",
    about: "Friendly and reliable dog walker. Your pup will have a great time!",
    location: maltaLocations[2],
    pricePerWalk: 1200, // €12
    availability: JSON.stringify(["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]),
    services: JSON.stringify(["Dog Walking", "Playtime", "Basic Training"]),
    certifications: JSON.stringify(["Dog Training Certificate"]),
    photoUrl: "/demo/walker-3.jpg",
  },
];

console.log("Seeding demo walkers...");
for (const walker of demoWalkers) {
  await db.insert(schema.walkers).values(walker);
}

// Demo meetups
const now = new Date();
const tomorrow = new Date(now);
tomorrow.setDate(tomorrow.getDate() + 1);
tomorrow.setHours(10, 0, 0, 0);

const nextWeek = new Date(now);
nextWeek.setDate(nextWeek.getDate() + 7);
nextWeek.setHours(16, 0, 0, 0);

const demoMeetups = [
  {
    organizerId: users[1].id,
    title: "Morning Beach Walk",
    description: "Casual morning walk along the beach. All friendly dogs welcome!",
    location: "Golden Bay, Malta",
    meetupTime: tomorrow,
    maxParticipants: 8,
    activityType: "walk",
    energyLevel: "medium",
  },
  {
    organizerId: users[3].id,
    title: "Puppy Playdate at the Park",
    description: "Socialization time for puppies under 1 year old",
    location: "San Anton Gardens, Malta",
    meetupTime: nextWeek,
    maxParticipants: 6,
    activityType: "playdate",
    energyLevel: "high",
  },
  {
    organizerId: users[5].id,
    title: "Evening Stroll in Valletta",
    description: "Relaxed evening walk through the historic streets",
    location: "Valletta, Malta",
    meetupTime: new Date(now.getTime() + 3 * 24 * 60 * 60 * 1000),
    maxParticipants: 10,
    activityType: "walk",
    energyLevel: "low",
  },
];

console.log("Seeding demo meetups...");
for (const meetup of demoMeetups) {
  await db.insert(schema.meetups).values(meetup);
}

// Add some meetup participants
const meetups = await db.select().from(schema.meetups);
if (meetups.length > 0) {
  console.log("Adding meetup participants...");
  await db.insert(schema.meetupParticipants).values([
    { meetupId: meetups[0].id, userId: users[0].id },
    { meetupId: meetups[0].id, userId: users[2].id },
    { meetupId: meetups[1].id, userId: users[4].id },
  ]);
}

// Add some reviews
const walkers = await db.select().from(schema.walkers);
if (walkers.length > 0) {
  console.log("Adding reviews...");
  await db.insert(schema.reviews).values([
    {
      walkerId: walkers[0].id,
      userId: users[1].id,
      rating: 5,
      comment: "Amazing service! My dog loves the walks with Maria.",
    },
    {
      walkerId: walkers[0].id,
      userId: users[3].id,
      rating: 5,
      comment: "Very professional and caring. Highly recommend!",
    },
    {
      walkerId: walkers[1].id,
      userId: users[5].id,
      rating: 4,
      comment: "Great pet sitter, very reliable and trustworthy.",
    },
  ]);
}

console.log("✅ Seed data created successfully!");
await connection.end();
